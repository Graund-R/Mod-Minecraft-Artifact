package weaponmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Летящий молот Тора: лёгкая молния по направлению полёта, урон касанием, воронка при касании блока, возврат. */
public class EntityHammer extends Entity {

    public static final int OUT = 0;
    public static final int BACK = 1;

    private static final DataParameter<ItemStack> STACK = EntityDataManager.createKey(EntityHammer.class, DataSerializers.ITEM_STACK);
    private static final DataParameter<Byte> STATE = EntityDataManager.createKey(EntityHammer.class, DataSerializers.BYTE);

    private UUID ownerId;
    private boolean creativeThrow;
    private int slot = -1;
    private double travelled;
    private int ticks;
    private int strikesLeft = HammerTuning.FLIGHT_STRIKES_MAX;
    private int strikeCooldown;
    private final Set<Integer> hitIds = new HashSet<Integer>();

    public EntityHammer(World world) {
        super(world);
        setSize(0.6F, 0.6F);
    }

    public EntityHammer(World world, EntityPlayer owner, ItemStack stack, int slot, boolean creative) {
        this(world);
        this.ownerId = owner.getUniqueID();
        this.slot = slot;
        this.creativeThrow = creative;
        setStack(stack);

        setLocationAndAngles(owner.posX, owner.posY + owner.getEyeHeight(), owner.posZ, owner.rotationYaw, owner.rotationPitch);
        float yawR = owner.rotationYaw * 0.017453292F;
        float pitchR = owner.rotationPitch * 0.017453292F;
        double dx = -MathHelper.sin(yawR) * MathHelper.cos(pitchR);
        double dy = -MathHelper.sin(pitchR);
        double dz = MathHelper.cos(yawR) * MathHelper.cos(pitchR);
        setPosition(owner.posX + dx * 0.7D, owner.posY + owner.getEyeHeight() - 0.2D + dy * 0.7D, owner.posZ + dz * 0.7D);
        this.motionX = dx * HammerTuning.SPEED;
        this.motionY = dy * HammerTuning.SPEED;
        this.motionZ = dz * HammerTuning.SPEED;
        updateRotationFromMotion();
        this.prevRotationYaw = this.rotationYaw;
        this.prevRotationPitch = this.rotationPitch;
    }

    @Override
    protected void entityInit() {
        this.dataManager.register(STACK, ItemStack.EMPTY);
        this.dataManager.register(STATE, Byte.valueOf((byte) OUT));
    }

    public ItemStack getStack() {
        return this.dataManager.get(STACK);
    }

    private void setStack(ItemStack s) {
        this.dataManager.set(STACK, s);
    }

    public int getState() {
        return this.dataManager.get(STATE).intValue();
    }

    private void setState(int s) {
        this.dataManager.set(STATE, Byte.valueOf((byte) s));
    }

    private EntityPlayer getOwner() {
        return ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
    }

    private void startBack() {
        if (getState() != BACK) {
            setState(BACK);
            hitIds.clear();
            ticks = 0;
            this.velocityChanged = true;
        }
    }

    // ---------- тик ----------

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            this.posX += this.motionX;
            this.posY += this.motionY;
            this.posZ += this.motionZ;
            setPosition(this.posX, this.posY, this.posZ);
            updateRotationFromMotion();
            wrapRotation();
            return;
        }
        ticks++;
        if (strikeCooldown > 0) {
            strikeCooldown--;
        }
        if (getState() == OUT) {
            tickOut();
        } else {
            tickBack();
        }
        updateRotationFromMotion();
        wrapRotation();
    }

    private void tickOut() {
        if (ticks > HammerTuning.MAX_OUT_TICKS) {
            startBack();
            return;
        }
        Vec3d pos = new Vec3d(this.posX, this.posY, this.posZ);
        Vec3d motion = new Vec3d(this.motionX, this.motionY, this.motionZ);
        double speed = motion.lengthVector();
        Vec3d dir = speed > 1.0E-4D ? motion.scale(1.0D / speed) : new Vec3d(0.0D, 1.0D, 0.0D);

        // молния: по направлению полёта в радиусе LIGHTNING_RANGE, касаться цели не обязательно
        if (strikesLeft > 0 && strikeCooldown <= 0) {
            EntityPlayer owner = getOwner();
            Vec3d target = Lightning.findTarget(world, owner, this, pos, dir, HammerTuning.LIGHTNING_RANGE);
            if (target != null) {
                Lightning.strike(world, owner, target);
                strikesLeft--;
                strikeCooldown = HammerTuning.FLIGHT_STRIKE_INTERVAL;
            }
        }

        Vec3d end = pos.add(motion);
        RayTraceResult blockHit = world.rayTraceBlocks(pos, end, false, true, false);
        boolean hitBlock = blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK;
        hitAlong(pos, hitBlock ? blockHit.hitVec : end);

        if (hitBlock) {
            setPosition(blockHit.hitVec.x, blockHit.hitVec.y, blockHit.hitVec.z);
            world.playSound(null, blockHit.hitVec.x, blockHit.hitVec.y, blockHit.hitVec.z,
                    SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.7F, 1.2F);
            if (HammerTuning.BLOCK_BREAK_ENABLED) {
                Crater.dig(world, blockHit.hitVec.add(dir.scale(0.3D)), HammerTuning.CRATER_RADIUS, HammerTuning.CRATER_MAX_HARDNESS);
            }
            startBack();
            return;
        }

        setPosition(end.x, end.y, end.z);
        travelled += speed;
        if (travelled >= HammerTuning.RANGE) {
            startBack();
        }
    }

    private void tickBack() {
        EntityPlayer owner = getOwner();
        if (owner == null || owner.isDead || ticks > HammerTuning.MAX_BACK_TICKS) {
            dropAsItem();
            return;
        }
        Vec3d target = new Vec3d(owner.posX, owner.posY + owner.height * 0.6D, owner.posZ);
        Vec3d to = target.subtract(this.posX, this.posY, this.posZ);
        double dist = to.lengthVector();
        if (dist < 1.4D) {
            giveToOwner(owner);
            return;
        }
        double spd = Math.min((double) HammerTuning.RETURN_SPEED, dist);
        Vec3d v = to.scale(spd / dist);
        this.motionX = v.x;
        this.motionY = v.y;
        this.motionZ = v.z;
        Vec3d pos = new Vec3d(this.posX, this.posY, this.posZ);
        Vec3d end = pos.add(v);
        hitAlong(pos, end);
        setPosition(end.x, end.y, end.z);
        this.velocityChanged = true;
    }

    // ---------- попадания по существам ----------

    private void hitAlong(Vec3d start, Vec3d end) {
        EntityPlayer owner = getOwner();
        List<Entity> nearby = world.getEntitiesWithinAABBExcludingEntity(this, new AxisAlignedBB(start, end).grow(1.0D));
        List<Hit> hits = new ArrayList<Hit>();
        for (Entity e : nearby) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive() || e == owner || hitIds.contains(e.getEntityId())) {
                continue;
            }
            AxisAlignedBB box = e.getEntityBoundingBox().grow(0.3D);
            RayTraceResult r = box.calculateIntercept(start, end);
            if (r != null) {
                hits.add(new Hit((EntityLivingBase) e, start.squareDistanceTo(r.hitVec)));
            } else if (box.contains(start)) {
                hits.add(new Hit((EntityLivingBase) e, 0.0D));
            }
        }
        Collections.sort(hits);
        for (Hit h : hits) {
            hitEntity(h.entity);
        }
    }

    private static class Hit implements Comparable<Hit> {
        final EntityLivingBase entity;
        final double dist;

        Hit(EntityLivingBase entity, double dist) {
            this.entity = entity;
            this.dist = dist;
        }

        @Override
        public int compareTo(Hit o) {
            return Double.compare(this.dist, o.dist);
        }
    }

    private void hitEntity(EntityLivingBase target) {
        hitIds.add(target.getEntityId());
        Entity owner = getOwner();
        boolean hurt = target.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), HammerTuning.THROW_DAMAGE);
        if (hurt) {
            double h = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (h > 1.0E-4D) {
                target.addVelocity(this.motionX / h * HammerTuning.KNOCKBACK, 0.2D, this.motionZ / h * HammerTuning.KNOCKBACK);
            }
            world.playSound(null, target.posX, target.posY, target.posZ, SoundEvents.ENTITY_IRONGOLEM_ATTACK,
                    SoundCategory.PLAYERS, 1.0F, 0.8F);
        }
    }

    // ---------- возврат в руку ----------

    private void giveToOwner(EntityPlayer owner) {
        if (!creativeThrow) {
            ItemStack s = getStack().copy();
            boolean placed = false;
            if (slot >= 0 && slot < 9 && owner.inventory.getStackInSlot(slot).isEmpty()) {
                owner.inventory.setInventorySlotContents(slot, s);
                placed = true;
            } else if (slot == -2 && owner.getHeldItemOffhand().isEmpty()) {
                owner.setHeldItem(EnumHand.OFF_HAND, s);
                placed = true;
            }
            if (!placed && !owner.inventory.addItemStackToInventory(s)) {
                owner.dropItem(s, false);
            }
        }
        world.playSound(null, owner.posX, owner.posY, owner.posZ, SoundEvents.ENTITY_ITEM_PICKUP,
                SoundCategory.PLAYERS, 0.5F, 0.8F);
        setDead();
    }

    private void dropAsItem() {
        if (!creativeThrow && !getStack().isEmpty()) {
            entityDropItem(getStack().copy(), 0.0F);
        }
        setDead();
    }

    // ---------- вращение ----------

    private void updateRotationFromMotion() {
        float h = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        if (h < 1.0E-4F && Math.abs(this.motionY) < 1.0E-4D) {
            return;
        }
        this.rotationYaw = (float) (MathHelper.atan2(this.motionX, this.motionZ) * (180.0D / Math.PI));
        this.rotationPitch = (float) (MathHelper.atan2(this.motionY, (double) h) * (180.0D / Math.PI));
    }

    private void wrapRotation() {
        while (this.rotationPitch - this.prevRotationPitch < -180.0F) {
            this.prevRotationPitch -= 360.0F;
        }
        while (this.rotationPitch - this.prevRotationPitch >= 180.0F) {
            this.prevRotationPitch += 360.0F;
        }
        while (this.rotationYaw - this.prevRotationYaw < -180.0F) {
            this.prevRotationYaw -= 360.0F;
        }
        while (this.rotationYaw - this.prevRotationYaw >= 180.0F) {
            this.prevRotationYaw += 360.0F;
        }
    }

    // ---------- сохранение ----------

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {
        if (c.hasUniqueId("Owner")) {
            this.ownerId = c.getUniqueId("Owner");
        }
        setStack(new ItemStack(c.getCompoundTag("Stack")));
        setState(c.getByte("State"));
        this.creativeThrow = c.getBoolean("Creative");
        this.slot = c.getInteger("Slot");
        this.travelled = c.getDouble("Travelled");
        this.strikesLeft = c.getInteger("StrikesLeft");
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {
        if (ownerId != null) {
            c.setUniqueId("Owner", ownerId);
        }
        c.setTag("Stack", getStack().writeToNBT(new NBTTagCompound()));
        c.setByte("State", (byte) getState());
        c.setBoolean("Creative", creativeThrow);
        c.setInteger("Slot", slot);
        c.setDouble("Travelled", travelled);
        c.setInteger("StrikesLeft", strikesLeft);
    }
}
