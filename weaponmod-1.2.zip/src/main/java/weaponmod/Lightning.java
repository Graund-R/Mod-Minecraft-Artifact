package weaponmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Поиск цели и удар молнии без поджога блоков. */
public final class Lightning {

    private Lightning() {}

    /**
     * Идём лучом от start по направлению dir на range блоков. Если луч упирается в блок или моба —
     * возвращаем точку удара (для моба: его ноги), иначе null.
     */
    public static Vec3d findTarget(World world, Entity owner, Entity self, Vec3d start, Vec3d dir, double range) {
        Vec3d end = start.add(dir.scale(range));
        RayTraceResult block = world.rayTraceBlocks(start, end, false, true, false);
        Vec3d limit = block != null ? block.hitVec : end;
        double best = block != null ? start.squareDistanceTo(block.hitVec) : Double.MAX_VALUE;
        Vec3d result = block != null ? block.hitVec : null;

        for (Entity e : world.getEntitiesWithinAABBExcludingEntity(self, new AxisAlignedBB(start, limit).grow(1.0D))) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive() || e == owner) {
                continue;
            }
            AxisAlignedBB box = e.getEntityBoundingBox().grow(0.4D);
            RayTraceResult r = box.calculateIntercept(start, limit);
            Vec3d p = r != null ? r.hitVec : (box.contains(start) ? start : null);
            if (p == null) {
                continue;
            }
            double d = start.squareDistanceTo(p);
            if (d < best) {
                best = d;
                result = new Vec3d(e.posX, e.posY, e.posZ);
            }
        }
        return result;
    }

    /** Молния в точке p: огонь на блоки не переходит, владелец не страдает. */
    public static void strike(World world, EntityPlayer owner, Vec3d p) {
        EntityLightningBolt bolt = new EntityLightningBolt(world, p.x, p.y, p.z, true);
        world.addWeatherEffect(bolt);

        double r = HammerTuning.LIGHTNING_RADIUS;
        AxisAlignedBB area = new AxisAlignedBB(p.x - r, p.y - 2.0D, p.z - r, p.x + r, p.y + 4.0D, p.z + r);
        for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, area)) {
            if (e == owner || !e.isEntityAlive()) {
                continue;
            }
            e.attackEntityFrom(DamageSource.LIGHTNING_BOLT, HammerTuning.LIGHTNING_DAMAGE);
            e.setFire(HammerTuning.LIGHTNING_FIRE_SECONDS);
            e.onStruckByLightning(bolt); // ванильные эффекты: заряженный крипер, свинья -> зомби-свинья и т.д.
        }
    }
}
