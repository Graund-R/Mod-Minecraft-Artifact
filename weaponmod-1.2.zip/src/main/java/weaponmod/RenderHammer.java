package weaponmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class RenderHammer extends Render<EntityHammer> {

    public RenderHammer(RenderManager manager) {
        super(manager);
    }

    @Override
    public void doRender(EntityHammer entity, double x, double y, double z, float entityYaw, float partialTicks) {
        ItemStack stack = entity.getStack();
        if (stack.isEmpty()) {
            return;
        }
        float yaw = entity.prevRotationYaw + (entity.rotationYaw - entity.prevRotationYaw) * partialTicks;
        float pitch = entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks;
        float spin = (entity.ticksExisted + partialTicks) * 40.0F;

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, (float) z);
        GlStateManager.rotate(yaw - 90.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(pitch, 0.0F, 0.0F, 1.0F);
        GlStateManager.rotate(spin, 0.0F, 0.0F, 1.0F);   // кувыркается в вертикальной плоскости полёта
        GlStateManager.enableRescaleNormal();
        GlStateManager.scale(1.6F, 1.6F, 1.6F);
        Minecraft.getMinecraft().getRenderItem().renderItem(stack, ItemCameraTransforms.TransformType.NONE);
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityHammer entity) {
        return TextureMap.LOCATION_BLOCKS_TEXTURE;
    }
}
