package weaponmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Огненная волна меча: видна частицами, летит по диагонали («/» или «\»), две волны образуют X. */
public class EntityWave extends Entity {

    private UUID ownerId;
    /** +1: волна «/», стартует слева и уходит вправо; -1: волна «\», справа налево. */
    private int side = 1;
    private int ticks;
    private boolean crossed;
    private double slashX, slashY, slashZ;
    private final Set<Integer> hitIds = new HashSet<Integer>();

    public EntityWave(World world) {
        super(world);
        setSize(0.6F, 0.6F);
        this.noClip = true;
    }

    public EntityWave(World world, EntityPlayer owner, int side) {
        this(world);
        this.ownerId = owner.getUniqueID();
        this.side = side;

        Vec3d look = owner.getLookVec();
        float yawR = owner.rotationYaw * 0.017453292F;
        Vec3d right = new Vec3d(-MathHelper.cos(yawR), 0.0D, -MathHelper.sin(yawR));

        // старт сбоку, дрейф к другой стороне: траектории соседних волн образуют X
        Vec3d start = new Vec3d(owner.posX, owner.posY + owner.getEyeHeight() - 0.3D, owner.posZ)
                .add(look.scale(1.0D))
                .subtract(right.scale(side * WaveTuning.START_OFFSET));
        setPosition(start.x, start.y, start.z);
        setLocationAndAngles(start.x, start.y, start.z, owner.rotationYaw, owner.rotationPitch);

        Vec3d motion = look.scale(WaveTuning.SPEED).add(right.scale(side * WaveTuning.LATERAL_SPEED));
        this.motionX = motion.x;
        this.motionY = motion.y;
        this.motionZ = motion.z;

        // направление «чёрточки» волны в плоскости (вправо, вверх)
        this.slashX = right.x * side * 0.7D;
        this.slashY = 0.7D;
        this.slashZ = right.z * side * 0.7D;
    }

    @Override
    protected void entityInit() {}

    private EntityPlayer getOwner() {
        return ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            return;
        }
        ticks++;
        if (ticks > WaveTuning.LIFETIME) {
            setDead();
            return;
        }

        Vec3d pos = new Vec3d(this.posX, this.posY, this.posZ);
        Vec3d motion = new Vec3d(this.motionX, this.motionY, this.motionZ);
        Vec3d end = pos.add(motion);

        RayTraceResult blockHit = world.rayTraceBlocks(pos, end, false, true, false);
        Vec3d stop = (blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK) ? blockHit.hitVec : end;
        damageAlong(pos, stop);
        if (stop != end) {
            puff(stop);
            setDead();
            return;
        }

        setPosition(end.x, end.y, end.z);
        checkCross();
        spawnSlashParticles();
    }

    private void damageAlong(Vec3d start, Vec3d end) {
        EntityPlayer owner = getOwner();
        for (Entity e : world.getEntitiesWithinAABBExcludingEntity(this, new AxisAlignedBB(start, end).grow(1.2D))) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive() || e == owner || hitIds.contains(e.getEntityId())) {
                continue;
            }
            AxisAlignedBB box = e.getEntityBoundingBox().grow(0.5D);
            if (box.calculateIntercept(start, end) != null || box.contains(start) || box.contains(end)) {
                hitIds.add(e.getEntityId());
                e.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), WaveTuning.DAMAGE);
                e.setFire(WaveTuning.FIRE_SECONDS);
            }
        }
    }

    /** Две волны разного наклона, пролетающие рядом, взрываются огнём с повышенным уроном. */
    private void checkCross() {
        if (crossed) {
            return;
        }
        for (EntityWave o : world.getEntitiesWithinAABB(EntityWave.class, getEntityBoundingBox().grow(WaveTuning.CROSS_DETECT))) {
            if (o == this || o.crossed || o.side == this.side || ownerId == null || !ownerId.equals(o.ownerId)) {
                continue;
            }
            Vec3d m = new Vec3d((this.posX + o.posX) * 0.5D, (this.posY + o.posY) * 0.5D, (this.posZ + o.posZ) * 0.5D);
            this.crossed = true;
            o.crossed = true;
            crossBurst(m);
            return;
        }
    }

    private void crossBurst(Vec3d m) {
        EntityPlayer owner = getOwner();
        double r = WaveTuning.CROSS_RADIUS;
        AxisAlignedBB area = new AxisAlignedBB(m.x - r, m.y - r, m.z - r, m.x + r, m.y + r, m.z + r);
        for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, area)) {
            if (e == owner || !e.isEntityAlive() || e.getDistance(m.x, m.y, m.z) > r) {
                continue;
            }
            e.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), WaveTuning.CROSS_DAMAGE);
            e.setFire(WaveTuning.CROSS_FIRE_SECONDS);
        }
        world.playSound(null, m.x, m.y, m.z, SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.0F, 0.8F);
        world.playSound(null, m.x, m.y, m.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.4F, 1.6F);
        if (world instanceof WorldServer) {
            WorldServer ws = (WorldServer) world;
            ws.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, m.x, m.y, m.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            ws.spawnParticle(EnumParticleTypes.FLAME, m.x, m.y, m.z, 40, 0.6D, 0.6D, 0.6D, 0.08D);
        }
    }

    private void puff(Vec3d p) {
        if (world instanceof WorldServer) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.FLAME, p.x, p.y, p.z, 12, 0.3D, 0.3D, 0.3D, 0.04D);
        }
    }

    private void spawnSlashParticles() {
        if (!(world instanceof WorldServer)) {
            return;
        }
        WorldServer ws = (WorldServer) world;
        for (int i = -3; i <= 3; i++) {
            double k = i * 0.3D;
            ws.spawnParticle(EnumParticleTypes.FLAME, this.posX + slashX * k, this.posY + slashY * k, this.posZ + slashZ * k,
                    0, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        ws.spawnParticle(EnumParticleTypes.CRIT, this.posX, this.posY, this.posZ, 0, 0.0D, 0.0D, 0.0D, 0.0D);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {
        setDead(); // волны недолговечны, после загрузки мира не восстанавливаем
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {}
}
