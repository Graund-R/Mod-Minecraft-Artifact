package weaponmod;

/** Числа баланса меча волн. */
public final class WaveTuning {

    private WaveTuning() {}

    /** Пауза между волнами, тики. */
    public static final int COOLDOWN_TICKS = 8;

    // полёт волны
    public static final float SPEED = 0.9F;
    public static final int LIFETIME = 28;
    /** Насколько в сторону волна стартует от центра и как быстро дрейфует к другой стороне (X-траектория). */
    public static final double START_OFFSET = 2.2D;
    public static final double LATERAL_SPEED = 0.16D;

    // урон (огонь)
    public static final float DAMAGE = 5.0F;
    public static final int FIRE_SECONDS = 4;

    // пересечение двух волн
    public static final float CROSS_DAMAGE = 12.0F;
    public static final int CROSS_FIRE_SECONDS = 8;
    public static final double CROSS_RADIUS = 3.0D;
    /** Волны считаются пересёкшимися, если ближе этого расстояния. */
    public static final double CROSS_DETECT = 1.3D;
}
