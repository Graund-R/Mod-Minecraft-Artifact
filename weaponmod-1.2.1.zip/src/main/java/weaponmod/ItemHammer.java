package weaponmod;

import com.google.common.collect.Multimap;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import javax.annotation.Nullable;
import java.util.List;

/** Молот Тора: каждый взмах бьёт молнией туда, куда направлен (в радиусе), плюс тяжёлый удар. */
public class ItemHammer extends Item {

    public ItemHammer(String name) {
        setRegistryName(WeaponMod.MODID, name);
        setUnlocalizedName(WeaponMod.MODID + "." + name);
        setMaxStackSize(1);
        setMaxDamage(HammerTuning.MAX_USES);
        setCreativeTab(CreativeTabs.COMBAT);
    }

    @Override
    public Multimap<String, AttributeModifier> getItemAttributeModifiers(EntityEquipmentSlot slot) {
        Multimap<String, AttributeModifier> map = super.getItemAttributeModifiers(slot);
        if (slot == EntityEquipmentSlot.MAINHAND) {
            map.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", (double) HammerTuning.MELEE_DAMAGE, 0));
            map.put(SharedMonsterAttributes.ATTACK_SPEED.getName(),
                    new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", HammerTuning.MELEE_ATTACK_SPEED, 0));
        }
        return map;
    }

    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        stack.damageItem(1, attacker);
        return true;
    }

    @Override
    public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos, EntityLivingBase entityLiving) {
        return true;
    }

    @Override
    public boolean canDestroyBlockInCreative(World world, BlockPos pos, ItemStack stack, EntityPlayer player) {
        return false;
    }

    @Override
    public boolean isFull3D() {
        return true;
    }

    /** Вызывается при каждом взмахе (на сервере тоже, когда клиент шлёт анимацию). */
    @Override
    public boolean onEntitySwing(EntityLivingBase entity, ItemStack stack) {
        if (!(entity instanceof EntityPlayer) || entity.world.isRemote) {
            return false;
        }
        EntityPlayer player = (EntityPlayer) entity;
        if (player.getCooldownTracker().hasCooldown(this)) {
            return false;
        }
        if (strike(player)) {
            player.getCooldownTracker().setCooldown(this, HammerTuning.STRIKE_COOLDOWN);
            stack.damageItem(1, player);
        }
        return false;
    }

    /** Ищет цель по направлению взгляда в радиусе и бьёт молнией. Возвращает true, если был удар. */
    private boolean strike(EntityPlayer player) {
        World world = player.world;
        double reach = HammerTuning.STRIKE_RADIUS;
        Vec3d eye = player.getPositionEyes(1.0F);
        Vec3d look = player.getLookVec();
        Vec3d end = eye.add(look.scale(reach));

        RayTraceResult blockHit = world.rayTraceBlocks(eye, end, false, true, false);
        boolean hasBlock = blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK;
        double best = hasBlock ? eye.distanceTo(blockHit.hitVec) : reach;

        Entity target = null;
        List<Entity> nearby = world.getEntitiesWithinAABBExcludingEntity(player, new AxisAlignedBB(eye, end).grow(1.0D));
        for (Entity e : nearby) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive()) {
                continue;
            }
            AxisAlignedBB box = e.getEntityBoundingBox().grow(0.4D);
            RayTraceResult r = box.calculateIntercept(eye, end);
            double d = -1.0D;
            if (r != null) {
                d = eye.distanceTo(r.hitVec);
            } else if (box.contains(eye)) {
                d = 0.0D;
            }
            if (d >= 0.0D && d < best) {
                best = d;
                target = e;
            }
        }

        Vec3d point;
        boolean onBlock = false;
        if (target != null) {
            point = new Vec3d(target.posX, target.posY, target.posZ);
        } else if (hasBlock) {
            point = blockHit.hitVec;
            onBlock = true;
        } else {
            return false;
        }

        lightning(player, point);

        if (onBlock && HammerTuning.BLOCK_BREAK_ENABLED && eye.distanceTo(point) <= HammerTuning.CONTACT_RANGE) {
            Vec3d c = point.add(look.scale(0.3D));
            int broken = Crater.blast(world, c, HammerTuning.CRATER_RADIUS, HammerTuning.CRATER_MAX_HARDNESS);
            if (broken > 0 && world instanceof WorldServer) {
                ((WorldServer) world).spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, c.x, c.y, c.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
        return true;
    }

    /** Молния без урона владельцу: сам разряд только визуальный, урон наносим вручную всем, кроме игрока. */
    private void lightning(EntityPlayer owner, Vec3d p) {
        World world = owner.world;
        EntityLightningBolt bolt = new EntityLightningBolt(world, p.x, p.y, p.z, true);
        world.addWeatherEffect(bolt);
        double r = HammerTuning.LIGHTNING_AOE;
        AxisAlignedBB area = new AxisAlignedBB(p.x - r, p.y - 2.0D, p.z - r, p.x + r, p.y + 5.0D, p.z + r);
        for (Entity e : world.getEntitiesWithinAABBExcludingEntity(bolt, area)) {
            if (e == owner || !(e instanceof EntityLivingBase) || !e.isEntityAlive()) {
                continue;
            }
            e.onStruckByLightning(bolt);
        }
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.translateToLocal("tooltip.weaponmod.hammer"));
    }
}
