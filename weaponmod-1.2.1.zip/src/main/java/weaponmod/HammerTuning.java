package weaponmod;

/** Числа баланса молота Тора. */
public final class HammerTuning {

    private HammerTuning() {}

    public static final int MAX_USES = 1561;

    // ближний бой (тяжёлый и медленный)
    public static final float MELEE_DAMAGE = 8.0F;
    public static final double MELEE_ATTACK_SPEED = -3.0D;

    // молния
    /** Радиус «зрения» молота: если взмах пересекает блок или моба в этом радиусе, бьёт молния. */
    public static final double STRIKE_RADIUS = 5.0D;
    /** Пауза между молниями, тики (в т.ч. при зажатом ЛКМ по блоку). */
    public static final int STRIKE_COOLDOWN = 25;
    /** Радиус поражения молнии вокруг точки удара. */
    public static final double LIGHTNING_AOE = 3.0D;

    // разрушение блоков, если молот «касается» блока
    public static final boolean BLOCK_BREAK_ENABLED = true;
    /** Касание: блок ближе этого расстояния. */
    public static final double CONTACT_RANGE = 3.5D;
    public static final float CRATER_RADIUS = 1.6F;
    public static final float CRATER_MAX_HARDNESS = 3.0F;
}
