package weaponmod;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Клиент -> сервер: игрок нажал ПКМ пустой рукой в воздух. */
public class RecallMessage implements IMessage {

    public RecallMessage() {}

    @Override
    public void fromBytes(ByteBuf buf) {}

    @Override
    public void toBytes(ByteBuf buf) {}

    public static class Handler implements IMessageHandler<RecallMessage, IMessage> {
        @Override
        public IMessage onMessage(RecallMessage message, MessageContext ctx) {
            final EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(new Runnable() {
                @Override
                public void run() {
                    if (player.getHeldItemMainhand().isEmpty()) {
                        SpearEvents.recall(player);
                    }
                }
            });
            return null;
        }
    }
}
