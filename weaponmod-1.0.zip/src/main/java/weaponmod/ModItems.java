package weaponmod;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = WeaponMod.MODID)
public class ModItems {

    public static final ItemSpear WOODEN_SPEAR = new ItemSpear("wooden_spear", Item.ToolMaterial.WOOD);
    public static final ItemSpear STONE_SPEAR = new ItemSpear("stone_spear", Item.ToolMaterial.STONE);
    public static final ItemSpear IRON_SPEAR = new ItemSpear("iron_spear", Item.ToolMaterial.IRON);
    public static final ItemSpear GOLDEN_SPEAR = new ItemSpear("golden_spear", Item.ToolMaterial.GOLD);
    public static final ItemSpear DIAMOND_SPEAR = new ItemSpear("diamond_spear", Item.ToolMaterial.DIAMOND);

    public static final ItemSpear[] SPEARS = {WOODEN_SPEAR, STONE_SPEAR, IRON_SPEAR, GOLDEN_SPEAR, DIAMOND_SPEAR};

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(SPEARS);
    }
}
