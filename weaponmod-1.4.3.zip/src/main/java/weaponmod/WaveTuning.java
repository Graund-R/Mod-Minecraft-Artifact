package weaponmod;

/** Числа баланса меча волн. */
public final class WaveTuning {

    private WaveTuning() {}

    /** Пауза между волнами, тики. */
    public static final int COOLDOWN_TICKS = 8;

    // полёт волны
    public static final float SPEED = 0.9F;
    public static final int LIFETIME = 30;
    /** Сбоку от центра волна стартует на этом расстоянии и дрейфует к другой стороне (X-траектория). */
    public static final double START_OFFSET = 2.2D;
    public static final double LATERAL_SPEED = 0.16D;

    // ширина: полудлина «чёрточки» растёт с расстоянием
    public static final double START_HALF = 0.8D;
    public static final double GROWTH_PER_TICK = 0.18D;
    /** Толщина зоны поражения вдоль полёта (плюс половина ширины цели). */
    public static final double HIT_THICKNESS = 0.9D;

    // урон (огонь), по всей длине волны
    public static final float DAMAGE = 6.0F;
    public static final int FIRE_SECONDS = 4;

    // поджог блоков
    public static final boolean IGNITE_BLOCKS = true;
    /** Не больше стольких новых огней за тик от одной волны. */
    public static final int IGNITE_MAX_PER_TICK = 3;

    // пересечение двух волн
    public static final float CROSS_DAMAGE = 14.0F;
    public static final int CROSS_FIRE_SECONDS = 8;
    public static final double CROSS_RADIUS = 3.5D;
    /** Волны считаются пересёкшимися, если их линии ближе этого расстояния. */
    public static final double CROSS_DETECT = 1.0D;
    /** Быстрый взмах: новая волна догоняет прошлую (другого наклона) за столько тиков, чтобы линии пересеклись. */
    public static final int CHASE_TICKS = 7;
    public static final double MAX_CHASE_SPEED = 2.8D;
}
