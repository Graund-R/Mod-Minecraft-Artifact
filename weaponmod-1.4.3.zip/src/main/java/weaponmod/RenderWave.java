package weaponmod;

import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.util.ResourceLocation;

/** Волна рисуется частицами с сервера, сама сущность невидима. */
public class RenderWave extends Render<EntityWave> {

    public RenderWave(RenderManager manager) {
        super(manager);
    }

    @Override
    public void doRender(EntityWave entity, double x, double y, double z, float entityYaw, float partialTicks) {
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityWave entity) {
        return TextureMap.LOCATION_BLOCKS_TEXTURE;
    }
}
