package weaponmod;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = WeaponMod.MODID, value = Side.CLIENT)
public class ClientHandler {

    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        for (ItemSpear item : ModItems.SPEARS) {
            ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
        }
        for (ItemDisc item : ModItems.DISCS) {
            ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
        }
        for (net.minecraft.item.Item item : ModItems.SINGLES) {
            ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
        }
    }

    public static void registerRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(EntitySpear.class, new IRenderFactory<EntitySpear>() {
            @Override
            public RenderSpear createRenderFor(RenderManager manager) {
                return new RenderSpear(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityDisc.class, new IRenderFactory<EntityDisc>() {
            @Override
            public RenderDisc createRenderFor(RenderManager manager) {
                return new RenderDisc(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityWave.class, new IRenderFactory<EntityWave>() {
            @Override
            public RenderWave createRenderFor(RenderManager manager) {
                return new RenderWave(manager);
            }
        });
    }
}
