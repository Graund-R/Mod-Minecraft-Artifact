package weaponmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityHanging;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.passive.EntityVillager;
/** Автоматическая защита жителей, питомцев и декоративных сущностей. */
public final class Safety {

    private Safety() {}

    /** Общий выключатель всех защит. */
    public static final boolean ENABLED = true;
    /** Снаряды (копьё, диск, волны) пролетают сквозь жителей и питомцев не раня их. */
    public static final boolean PROTECT_ENTITIES = true;

    public static boolean isProtectedEntity(Entity e) {
        if (!ENABLED || !PROTECT_ENTITIES) {
            return false;
        }
        if (e instanceof EntityVillager || e instanceof EntityHanging || e instanceof EntityArmorStand) {
            return true;
        }
        if (e instanceof EntityTameable && ((EntityTameable) e).isTamed()) {
            return true;
        }
        if (e instanceof AbstractHorse && ((AbstractHorse) e).isTame()) {
            return true;
        }
        return e instanceof EntityIronGolem && ((EntityIronGolem) e).isPlayerCreated();
    }
}
