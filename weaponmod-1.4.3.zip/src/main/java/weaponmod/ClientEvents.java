package weaponmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Анимации от первого лица:
 * копьё: заряд (отвод назад и вздрагивание) и удар как выпад вперёд;
 * молот: подъём над головой при заряде.
 */
@Mod.EventBusSubscriber(modid = WeaponMod.MODID, value = Side.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onRenderHand(RenderSpecificHandEvent event) {
        if (event.getHand() != EnumHand.MAIN_HAND) {
            return;
        }
        ItemStack stack = event.getItemStack();
        boolean spear = stack.getItem() instanceof ItemSpear;
        boolean hammer = stack.getItem() instanceof ItemHammer;
        if (!spear && !hammer) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP player = mc.player;
        if (player == null) {
            return;
        }
        float pt = event.getPartialTicks();
        boolean charging = player.isHandActive() && player.getActiveHand() == EnumHand.MAIN_HAND;
        float swing = event.getSwingProgress();
        if (!charging && (hammer || swing <= 0.0F || mc.gameSettings.keyBindUseItem.isKeyDown())) {
            return; // обычная поза и обычный взмах молота оставляем ванильными
        }

        boolean right = player.getPrimaryHand() == EnumHandSide.RIGHT;
        float s = right ? 1.0F : -1.0F;

        GlStateManager.pushMatrix();
        GlStateManager.translate(s * 0.56F, -0.52F + event.getEquipProgress() * -0.6F, -0.72F);

        if (charging) {
            float ticks = stack.getMaxItemUseDuration() - (player.getItemInUseCount() - pt + 1.0F);
            float full = spear ? (float) SpearTuning.FULL_CHARGE_TICKS : (float) HammerTuning.CHARGE_FULL_TICKS;
            float c = MathHelper.clamp(ticks / full, 0.0F, 1.0F);
            float t = player.ticksExisted + pt;
            if (spear) {
                GlStateManager.translate(s * -0.05F * c, 0.08F * c, 0.45F * c);
                GlStateManager.rotate(-65.0F * c, 1.0F, 0.0F, 0.0F); // острие смотрит вперёд
                GlStateManager.rotate(s * 10.0F * c, 0.0F, 1.0F, 0.0F);
            } else {
                GlStateManager.translate(s * -0.1F * c, 0.35F * c, 0.1F * c);
                GlStateManager.rotate(-55.0F * c, 1.0F, 0.0F, 0.0F);
            }
            boolean ready = spear ? ticks >= SpearTuning.EXPLOSIVE_CHARGE_TICKS : c >= 1.0F;
            if (ready) {
                GlStateManager.translate(MathHelper.sin(t * 2.7F) * 0.012F, MathHelper.sin(t * 3.1F) * 0.012F, 0.0F);
            }
            mc.getItemRenderer().renderItemSide(player, stack,
                    right ? ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND
                          : ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND, !right);
        } else {
            renderSpearThrust(mc, player, stack, swing, right);
        }
        GlStateManager.popMatrix();
        event.setCanceled(true);
    }

    private static void renderSpearThrust(Minecraft mc, EntityPlayerSP player, ItemStack stack,
                                          float swing, boolean right) {
        float turn = smoothStep(swing / 0.34F) * (1.0F - smoothStep((swing - 0.78F) / 0.22F));
        float thrust = smoothStep((swing - 0.34F) / 0.20F) * (1.0F - smoothStep((swing - 0.54F) / 0.24F));
        float side = right ? 1.0F : -1.0F;
        GlStateManager.translate(side * (0.071F - 0.10F * thrust), 0.20F, 0.071F - 0.86F * thrust);
        // Сначала разворачиваем острие по направлению взгляда, затем выдвигаем копьё по этой оси.
        GlStateManager.rotate(right ? -90.0F : 90.0F - 180.0F * turn, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(side * 25.0F + (135.0F - side * 25.0F) * turn, 0.0F, 0.0F, 1.0F);
        GlStateManager.scale(0.85F, 0.85F, 0.85F);
        mc.getItemRenderer().renderItemSide(player, stack, ItemCameraTransforms.TransformType.NONE, !right);
    }

    private static float smoothStep(float progress) {
        float t = MathHelper.clamp(progress, 0.0F, 1.0F);
        return t * t * (3.0F - 2.0F * t);
    }
}
