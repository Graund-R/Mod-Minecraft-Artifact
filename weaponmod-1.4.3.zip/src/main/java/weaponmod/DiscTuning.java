package weaponmod;

/** Числа баланса метательного диска (как «Throwing Disc» от Mojang). */
public final class DiscTuning {

    private DiscTuning() {}

    // --- полёт ---
    /** Скорость, блоков/тик. */
    public static final float SPEED = 1.8F;
    /** Дальность первого броска: BASE_RANGE + 2 * уровень добычи материала (золото 14, железо 18, алмаз 20). */
    public static final double BASE_RANGE = 14.0D;
    /** Сколько блоков дальности добавляет каждый рикошет. */
    public static final double BOUNCE_RANGE_BONUS = 8.0D;
    public static final int MAX_BOUNCES = 4;
    public static final int MAX_OUT_TICKS = 160;

    // --- рикошет: усиление и наведение ---
    /** Во сколько раз растёт урон после каждого рикошета. */
    public static final float BOUNCE_DAMAGE_MULT = 1.3F;
    /** После рикошета диск разворачивается к ближайшему враждебному мобу в этом радиусе. */
    public static final double HOMING_RADIUS = 12.0D;

    // --- поджог блоков ---
    public static final boolean IGNITE_BLOCKS = false; // поджог теперь у меча волн; true вернёт его диску
    /** След огня: каждые столько тиков в полёте. */
    public static final int TRAIL_INTERVAL = 3;

    // --- возврат ---
    public static final float RETURN_SPEED = 1.7F;
    public static final int MAX_BACK_TICKS = 300;

    // --- урон ---
    /** Урон броска = BASE_DAMAGE + урон материала (золото 3.5, железо 5.5, алмаз 6.5). Бьёт и на вылете, и на возврате. */
    public static final float BASE_DAMAGE = 3.5F;
    /** Откид цели вдоль полёта. */
    public static final float KNOCKBACK = 0.3F;

    // --- ближний бой (слабый, но быстрый) ---
    public static final float MELEE_BASE_DAMAGE = 4.0F;
    public static final double MELEE_ATTACK_SPEED = -2.0D;
}
