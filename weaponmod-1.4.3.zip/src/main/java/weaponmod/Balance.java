package weaponmod;

/** Общий баланс прочности всего оружия мода. */
public final class Balance {

    private Balance() {}

    /** Прочность всех орудий = ванильная прочность материала / это число (минимум 1). */
    public static final int DURABILITY_DIVISOR = 5;

    /** Нижняя граница, чтобы золото (ваниль 32) не стало одноразовым: золото 50, алмаз 312. */
    public static final int MIN_DURABILITY = 50;

    public static int durability(int vanillaUses) {
        return Math.max(MIN_DURABILITY, vanillaUses / DURABILITY_DIVISOR);
    }
}
