package weaponmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class RenderDisc extends Render<EntityDisc> {

    public RenderDisc(RenderManager manager) {
        super(manager);
    }

    @Override
    public void doRender(EntityDisc entity, double x, double y, double z, float entityYaw, float partialTicks) {
        ItemStack stack = entity.getStack();
        if (stack.isEmpty()) {
            return;
        }
        float spin = (entity.ticksExisted + partialTicks) * 45.0F;

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, (float) z);
        GlStateManager.enableRescaleNormal();
        GlStateManager.rotate(spin, 0.0F, 1.0F, 0.0F);   // вращение вокруг вертикали
        GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);   // диск лежит плашмя
        GlStateManager.scale(1.3F, 1.3F, 1.3F);
        Minecraft.getMinecraft().getRenderItem().renderItem(stack, ItemCameraTransforms.TransformType.NONE);
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityDisc entity) {
        return TextureMap.LOCATION_BLOCKS_TEXTURE;
    }
}
