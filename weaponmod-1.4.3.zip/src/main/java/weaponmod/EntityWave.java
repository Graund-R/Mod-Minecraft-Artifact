package weaponmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Огненная волна меча. Видна частицами: «чёрточка» «/» или «\», которая растёт в ширину с расстоянием.
 * Урон наносится по всей её длине, а не только в центре. Две волны разного наклона образуют X.
 */
public class EntityWave extends Entity {

    private UUID ownerId;
    /** +1: волна «/», стартует слева и уходит вправо; -1: «\», справа налево. */
    private int side = 1;
    private int ticks;
    private boolean crossed;
    /** Единичное направление «чёрточки». */
    private double sx, sy, sz;
    private final Set<Integer> hitIds = new HashSet<Integer>();

    public EntityWave(World world) {
        super(world);
        setSize(0.6F, 0.6F);
        this.noClip = true;
    }

    public EntityWave(World world, EntityPlayer owner, int side) {
        this(world);
        this.ownerId = owner.getUniqueID();
        this.side = side;

        Vec3d look = owner.getLookVec();
        float yawR = owner.rotationYaw * 0.017453292F;
        Vec3d right = new Vec3d(-MathHelper.cos(yawR), 0.0D, -MathHelper.sin(yawR));

        Vec3d start = new Vec3d(owner.posX, owner.posY + owner.getEyeHeight() - 0.3D, owner.posZ)
                .add(look.scale(1.0D))
                .subtract(right.scale(side * WaveTuning.START_OFFSET));
        Vec3d motion = look.scale(WaveTuning.SPEED).add(right.scale(side * WaveTuning.LATERAL_SPEED));

        // быстрый взмах: догоняем недавнюю волну другого наклона, чтобы линии точно пересеклись (X)
        EntityWave prev = findChaseTarget(owner);
        if (prev != null) {
            double t = WaveTuning.CHASE_TICKS;
            Vec3d meet = new Vec3d(prev.posX + prev.motionX * t, prev.posY + prev.motionY * t, prev.posZ + prev.motionZ * t);
            Vec3d v = meet.subtract(start).scale(1.0D / t);
            if (v.lengthVector() <= WaveTuning.MAX_CHASE_SPEED) {
                motion = v;
            }
        }

        setPosition(start.x, start.y, start.z);
        setLocationAndAngles(start.x, start.y, start.z, owner.rotationYaw, owner.rotationPitch);
        this.motionX = motion.x;
        this.motionY = motion.y;
        this.motionZ = motion.z;

        // «чёрточка» лежит в плоскости (вправо, вверх)
        this.sx = right.x * side * 0.7071D;
        this.sy = 0.7071D;
        this.sz = right.z * side * 0.7071D;
    }

    private EntityWave findChaseTarget(EntityPlayer owner) {
        EntityWave best = null;
        for (EntityWave w : world.getEntitiesWithinAABB(EntityWave.class, owner.getEntityBoundingBox().grow(80.0D))) {
            if (w.isDead || w.crossed || w.side == this.side || !owner.getUniqueID().equals(w.ownerId)) {
                continue;
            }
            if (w.ticks + WaveTuning.CHASE_TICKS > WaveTuning.LIFETIME) {
                continue;
            }
            if (best == null || w.ticks < best.ticks) {
                best = w;
            }
        }
        return best;
    }

    @Override
    protected void entityInit() {}

    private EntityPlayer getOwner() {
        return ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
    }

    private double halfLen() {
        return WaveTuning.START_HALF + WaveTuning.GROWTH_PER_TICK * ticks;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            return;
        }
        ticks++;
        if (ticks > WaveTuning.LIFETIME) {
            setDead();
            return;
        }

        Vec3d pos = new Vec3d(this.posX, this.posY, this.posZ);
        Vec3d motion = new Vec3d(this.motionX, this.motionY, this.motionZ);
        Vec3d end = pos.add(motion);

        RayTraceResult blockHit = world.rayTraceBlocks(pos, end, false, true, false);
        boolean blocked = blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK;
        sweepDamage(pos, blocked ? blockHit.hitVec : end);
        if (blocked) {
            puff(blockHit.hitVec);
            if (blockHit.sideHit != null) {
                ignite(blockHit.getBlockPos().offset(blockHit.sideHit));
            }
            setDead();
            return;
        }

        setPosition(end.x, end.y, end.z);
        if (WaveTuning.IGNITE_BLOCKS && ticks % 2 == 0) {
            igniteAlong();
        }
        checkCross();
        spawnSlashParticles(motion);
    }

    // ---------- урон по всей длине волны ----------

    private void sweepDamage(Vec3d from, Vec3d to) {
        EntityPlayer owner = getOwner();
        double len = halfLen();
        Vec3d mid = from.add(to).scale(0.5D);
        for (Entity e : world.getEntitiesWithinAABBExcludingEntity(this, new AxisAlignedBB(from, to).grow(len + 1.5D))) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive() || e == owner || hitIds.contains(e.getEntityId()) || Safety.isProtectedEntity(e)) {
                continue;
            }
            double reach = WaveTuning.HIT_THICKNESS + e.width * 0.5D;
            double[] ys = {e.posY + 0.1D, e.posY + e.height * 0.5D, e.posY + e.height - 0.1D};
            boolean hit = false;
            for (double y : ys) {
                Vec3d p = new Vec3d(e.posX, y, e.posZ);
                if (distToSlash(p, mid, len) <= reach || distToSlash(p, to, len) <= reach) {
                    hit = true;
                    break;
                }
            }
            if (hit) {
                hitIds.add(e.getEntityId());
                e.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), WaveTuning.DAMAGE);
                e.setFire(WaveTuning.FIRE_SECONDS);
            }
        }
    }

    /** Расстояние от точки до отрезка «чёрточки» с центром c и полудлиной len. */
    private double distToSlash(Vec3d p, Vec3d c, double len) {
        return distPointSegment(p,
                new Vec3d(c.x - sx * len, c.y - sy * len, c.z - sz * len),
                new Vec3d(c.x + sx * len, c.y + sy * len, c.z + sz * len));
    }

    private static double distPointSegment(Vec3d p, Vec3d a, Vec3d b) {
        double abx = b.x - a.x, aby = b.y - a.y, abz = b.z - a.z;
        double len2 = abx * abx + aby * aby + abz * abz;
        double t = 0.0D;
        if (len2 > 1.0E-9D) {
            t = ((p.x - a.x) * abx + (p.y - a.y) * aby + (p.z - a.z) * abz) / len2;
            t = Math.max(0.0D, Math.min(1.0D, t));
        }
        double dx = a.x + abx * t - p.x;
        double dy = a.y + aby * t - p.y;
        double dz = a.z + abz * t - p.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ---------- поджог блоков ----------

    private void ignite(BlockPos pos) {
        if (WaveTuning.IGNITE_BLOCKS && world.isAirBlock(pos) && Blocks.FIRE.canPlaceBlockAt(world, pos)) {
            world.setBlockState(pos, Blocks.FIRE.getDefaultState());
        }
    }

    /** Огонь вдоль всей длины волны там, где он может держаться (на твёрдой опоре или рядом с горючим). */
    private void igniteAlong() {
        double len = halfLen();
        int placed = 0;
        for (double k = -len; k <= len && placed < WaveTuning.IGNITE_MAX_PER_TICK; k += 1.0D) {
            BlockPos bp = new BlockPos(this.posX + sx * k, this.posY + sy * k, this.posZ + sz * k);
            if (world.isAirBlock(bp) && Blocks.FIRE.canPlaceBlockAt(world, bp)) {
                world.setBlockState(bp, Blocks.FIRE.getDefaultState());
                placed++;
            }
        }
    }

    // ---------- пересечение волн ----------

    private void checkCross() {
        if (crossed) {
            return;
        }
        double len = halfLen();
        Vec3d here = new Vec3d(this.posX, this.posY, this.posZ);
        for (EntityWave o : world.getEntitiesWithinAABB(EntityWave.class, getEntityBoundingBox().grow(len + 8.0D))) {
            if (o == this || o.isDead || o.crossed || o.side == this.side || ownerId == null || !ownerId.equals(o.ownerId)) {
                continue;
            }
            double olen = o.halfLen();
            Vec3d oHere = new Vec3d(o.posX, o.posY, o.posZ);
            Vec3d oa = new Vec3d(oHere.x - o.sx * olen, oHere.y - o.sy * olen, oHere.z - o.sz * olen);
            Vec3d ob = new Vec3d(oHere.x + o.sx * olen, oHere.y + o.sy * olen, oHere.z + o.sz * olen);
            for (int i = -3; i <= 3; i++) {
                double k = len * i / 3.0D;
                Vec3d p = new Vec3d(here.x + sx * k, here.y + sy * k, here.z + sz * k);
                if (distPointSegment(p, oa, ob) <= WaveTuning.CROSS_DETECT) {
                    this.crossed = true;
                    o.crossed = true;
                    crossBurst(p);
                    return;
                }
            }
        }
    }

    private void crossBurst(Vec3d m) {
        EntityPlayer owner = getOwner();
        double r = WaveTuning.CROSS_RADIUS;
        AxisAlignedBB area = new AxisAlignedBB(m.x - r, m.y - r, m.z - r, m.x + r, m.y + r, m.z + r);
        for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, area)) {
            if (e == owner || !e.isEntityAlive() || Safety.isProtectedEntity(e) || e.getDistance(m.x, m.y, m.z) > r) {
                continue;
            }
            e.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), WaveTuning.CROSS_DAMAGE);
            e.setFire(WaveTuning.CROSS_FIRE_SECONDS);
        }
        world.playSound(null, m.x, m.y, m.z, SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.0F, 0.8F);
        world.playSound(null, m.x, m.y, m.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.4F, 1.6F);
        if (world instanceof WorldServer) {
            WorldServer ws = (WorldServer) world;
            ws.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, m.x, m.y, m.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            ws.spawnParticle(EnumParticleTypes.FLAME, m.x, m.y, m.z, 50, 0.8D, 0.8D, 0.8D, 0.1D);
        }
        // после пересечения быстрая волна возвращается к обычной скорости
        capSpeed(this);
    }

    private static void capSpeed(EntityWave w) {
        double max = WaveTuning.SPEED * 1.3D;
        double v = Math.sqrt(w.motionX * w.motionX + w.motionY * w.motionY + w.motionZ * w.motionZ);
        if (v > max) {
            double k = max / v;
            w.motionX *= k;
            w.motionY *= k;
            w.motionZ *= k;
        }
    }

    private void puff(Vec3d p) {
        if (world instanceof WorldServer) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.FLAME, p.x, p.y, p.z, 14, 0.3D, 0.3D, 0.3D, 0.04D);
        }
    }

    // ---------- видимость: дуга из частиц, растущая с расстоянием ----------

    private void spawnSlashParticles(Vec3d motion) {
        if (!(world instanceof WorldServer)) {
            return;
        }
        WorldServer ws = (WorldServer) world;
        double len = halfLen();
        double speed = motion.lengthVector();
        double fx = 0.0D, fy = 0.0D, fz = 0.0D;
        if (speed > 1.0E-4D) {
            fx = motion.x / speed;
            fy = motion.y / speed;
            fz = motion.z / speed;
        }
        int n = (int) (len / 0.35D);
        for (int i = -n; i <= n; i++) {
            double k = i * 0.35D;
            double bulge = 0.4D * (1.0D - (k * k) / (len * len)); // центр выгнут вперёд, как серп
            ws.spawnParticle(EnumParticleTypes.FLAME,
                    this.posX + sx * k + fx * bulge, this.posY + sy * k + fy * bulge, this.posZ + sz * k + fz * bulge,
                    0, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        ws.spawnParticle(EnumParticleTypes.CRIT, this.posX + sx * len, this.posY + sy * len, this.posZ + sz * len, 0, 0.0D, 0.0D, 0.0D, 0.0D);
        ws.spawnParticle(EnumParticleTypes.CRIT, this.posX - sx * len, this.posY - sy * len, this.posZ - sz * len, 0, 0.0D, 0.0D, 0.0D, 0.0D);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {
        setDead(); // волны недолговечны
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {}
}
