package weaponmod;

import com.google.common.collect.Multimap;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class ItemSpear extends Item {

    private final Item.ToolMaterial material;

    public ItemSpear(String name, Item.ToolMaterial material) {
        this.material = material;
        setRegistryName(WeaponMod.MODID, name);
        setUnlocalizedName(WeaponMod.MODID + "." + name);
        setMaxStackSize(1);
        setMaxDamage(Balance.durability(material.getMaxUses()));
        setCreativeTab(CreativeTabs.COMBAT);
    }

    public float getThrowBaseDamage() {
        return SpearTuning.THROW_BASE_DAMAGE + material.getAttackDamage();
    }

    // ---------- ближний бой ----------

    @Override
    public Multimap<String, AttributeModifier> getItemAttributeModifiers(EntityEquipmentSlot slot) {
        Multimap<String, AttributeModifier> map = super.getItemAttributeModifiers(slot);
        if (slot == EntityEquipmentSlot.MAINHAND) {
            map.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier",
                            (double) (SpearTuning.MELEE_BASE_DAMAGE + material.getAttackDamage()), 0));
            map.put(SharedMonsterAttributes.ATTACK_SPEED.getName(),
                    new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", SpearTuning.MELEE_ATTACK_SPEED, 0));
        }
        return map;
    }

    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        stack.damageItem(1, attacker);
        return true;
    }

    @Override
    public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos, EntityLivingBase entityLiving) {
        if ((double) state.getBlockHardness(worldIn, pos) != 0.0D) {
            stack.damageItem(2, entityLiving);
        }
        return true;
    }

    @Override
    public boolean canDestroyBlockInCreative(World world, BlockPos pos, ItemStack stack, EntityPlayer player) {
        return false;
    }

    @Override
    public boolean isFull3D() {
        return true;
    }

    @Override
    public int getItemEnchantability() {
        return material.getEnchantability();
    }

    @Override
    public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
        ItemStack mat = this.material.getRepairItemStack();
        if (!mat.isEmpty() && net.minecraftforge.oredict.OreDictionary.itemMatches(mat, repair, false)) {
            return true;
        }
        return super.getIsRepairable(toRepair, repair);
    }

    // ---------- заряд и бросок ----------

    @Override
    public EnumAction getItemUseAction(ItemStack stack) {
        return EnumAction.NONE; // поза заряда рисуется в ClientEvents (не как у лука)
    }

    /** Тычок на расстоянии: если цель дальше ванильных 3 блоков, но в пределах MELEE_REACH, бьём её. */
    @Override
    public boolean onEntitySwing(EntityLivingBase entity, ItemStack stack) {
        if (!(entity instanceof EntityPlayer) || entity.world.isRemote) {
            return false;
        }
        EntityPlayer player = (EntityPlayer) entity;
        if (SpearEvents.isInteractSwing(player)) {
            return false;
        }
        World world = player.world;
        double reach = SpearTuning.MELEE_REACH;
        Vec3d eye = player.getPositionEyes(1.0F);
        Vec3d end = eye.add(player.getLookVec().scale(reach));
        RayTraceResult bh = world.rayTraceBlocks(eye, end, false, true, false);
        double limit = (bh != null && bh.typeOfHit == RayTraceResult.Type.BLOCK) ? eye.distanceTo(bh.hitVec) : reach;
        Entity best = null;
        double bestD = limit;
        for (Entity e : world.getEntitiesWithinAABBExcludingEntity(player, new AxisAlignedBB(eye, end).grow(1.0D))) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive()) {
                continue;
            }
            AxisAlignedBB box = e.getEntityBoundingBox().grow((double) e.getCollisionBorderSize());
            RayTraceResult r = box.calculateIntercept(eye, end);
            if (r != null) {
                double d = eye.distanceTo(r.hitVec);
                if (d < bestD) {
                    bestD = d;
                    best = e;
                }
            }
        }
        if (best != null && bestD > SpearTuning.VANILLA_REACH) {
            player.attackTargetEntityWithCurrentItem(best);
        }
        return false;
    }

    /** Сигнал: заряд достиг взрывного порога. */
    @Override
    public void onUsingTick(ItemStack stack, EntityLivingBase player, int count) {
        if (player.world.isRemote) {
            return;
        }
        int charge = getMaxItemUseDuration(stack) - count;
        if (charge == SpearTuning.EXPLOSIVE_CHARGE_TICKS) {
            player.world.playSound(null, player.posX, player.posY, player.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
                    SoundCategory.PLAYERS, 0.8F, 1.6F);
        }
    }

    @Override
    public int getMaxItemUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        // Shift + щит в левой руке: отдаём ПКМ щиту (блок), а не заряду броска
        ItemStack off = player.getHeldItemOffhand();
        if (hand == EnumHand.MAIN_HAND && player.isSneaking() && !off.isEmpty() && off.getItem().isShield(off, player)) {
            return new ActionResult<ItemStack>(EnumActionResult.PASS, stack);
        }
        player.setActiveHand(hand);
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    public void onPlayerStoppedUsing(ItemStack stack, World world, EntityLivingBase entity, int timeLeft) {
        if (!(entity instanceof EntityPlayer)) {
            return;
        }
        EntityPlayer player = (EntityPlayer) entity;
        int charge = getMaxItemUseDuration(stack) - timeLeft;
        if (charge < SpearTuning.MIN_CHARGE_TICKS) {
            return;
        }
        float power = Math.min(1.0F, (float) charge / (float) SpearTuning.FULL_CHARGE_TICKS);
        boolean explosive = charge >= SpearTuning.EXPLOSIVE_CHARGE_TICKS;

        if (!world.isRemote) {
            boolean creative = player.capabilities.isCreativeMode;
            ItemStack thrown = stack.copy();
            thrown.setCount(1);
            if (!creative) {
                thrown.damageItem(1, player);
            }
            if (!thrown.isEmpty()) {
                world.spawnEntity(new EntitySpear(world, player, thrown, power, creative, explosive));
            }
            if (!creative) {
                stack.shrink(1);
            }
        }
        world.playSound(null, player.posX, player.posY, player.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                SoundCategory.PLAYERS, 1.0F, 0.6F + 0.3F * (1.0F - power));
        world.playSound(null, player.posX, player.posY, player.posZ, SoundEvents.ENTITY_SNOWBALL_THROW,
                SoundCategory.PLAYERS, 0.6F, 0.5F);
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.translateToLocal("tooltip.weaponmod.spear"));
    }
}
