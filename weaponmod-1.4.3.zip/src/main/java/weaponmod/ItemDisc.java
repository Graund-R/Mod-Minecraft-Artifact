package weaponmod;

import com.google.common.collect.Multimap;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

/** Метательный диск: бросок по ПКМ, летит вперёд, отскакивает от блоков и возвращается в руку. */
public class ItemDisc extends Item {

    private final Item.ToolMaterial material;

    public ItemDisc(String name, Item.ToolMaterial material) {
        this.material = material;
        setRegistryName(WeaponMod.MODID, name);
        setUnlocalizedName(WeaponMod.MODID + "." + name);
        setMaxStackSize(1);
        setMaxDamage(Balance.durability(material.getMaxUses()));
        setCreativeTab(CreativeTabs.COMBAT);
    }

    public float getThrowDamage() {
        return DiscTuning.BASE_DAMAGE + material.getAttackDamage();
    }

    public double getRange() {
        return DiscTuning.BASE_RANGE + 2.0D * material.getHarvestLevel();
    }

    // ---------- ближний бой ----------

    @Override
    public Multimap<String, AttributeModifier> getItemAttributeModifiers(EntityEquipmentSlot slot) {
        Multimap<String, AttributeModifier> map = super.getItemAttributeModifiers(slot);
        if (slot == EntityEquipmentSlot.MAINHAND) {
            map.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier",
                            (double) (DiscTuning.MELEE_BASE_DAMAGE + material.getAttackDamage()), 0));
            map.put(SharedMonsterAttributes.ATTACK_SPEED.getName(),
                    new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", DiscTuning.MELEE_ATTACK_SPEED, 0));
        }
        return map;
    }

    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        stack.damageItem(1, attacker);
        return true;
    }

    @Override
    public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos, EntityLivingBase entityLiving) {
        return true;
    }

    @Override
    public boolean canDestroyBlockInCreative(World world, BlockPos pos, ItemStack stack, EntityPlayer player) {
        return false;
    }

    @Override
    public int getItemEnchantability() {
        return material.getEnchantability();
    }

    @Override
    public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
        ItemStack mat = this.material.getRepairItemStack();
        if (!mat.isEmpty() && net.minecraftforge.oredict.OreDictionary.itemMatches(mat, repair, false)) {
            return true;
        }
        return super.getIsRepairable(toRepair, repair);
    }

    // ---------- бросок ----------

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);

        // Shift + щит в другой руке: ПКМ отдаём щиту
        ItemStack other = player.getHeldItem(hand == EnumHand.MAIN_HAND ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
        if (hand == EnumHand.MAIN_HAND && player.isSneaking() && !other.isEmpty() && other.getItem().isShield(other, player)) {
            return new ActionResult<ItemStack>(EnumActionResult.PASS, stack);
        }

        if (!world.isRemote) {
            boolean creative = player.capabilities.isCreativeMode;
            ItemStack thrown = stack.copy();
            thrown.setCount(1);
            if (!creative) {
                thrown.damageItem(1, player);
            }
            if (!thrown.isEmpty()) {
                int slot = hand == EnumHand.MAIN_HAND ? player.inventory.currentItem : -2;
                world.spawnEntity(new EntityDisc(world, player, thrown, slot, getThrowDamage(), getRange(), creative));
            }
            if (!creative) {
                stack.shrink(1);
            }
        }
        world.playSound(null, player.posX, player.posY, player.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                SoundCategory.PLAYERS, 0.9F, 1.4F);
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.translateToLocal("tooltip.weaponmod.disc"));
    }
}
