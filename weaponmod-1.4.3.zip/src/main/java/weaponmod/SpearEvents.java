package weaponmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = WeaponMod.MODID)
public class SpearEvents {

    private static final String KEY_RC = "weaponmod_rc_time";

    /**
     * Взмах руки приходит и от ЛКМ (атака), и от ПКМ по сундуку, двери, печи и т. п.
     * Взмах сразу после ПКМ-взаимодействия атакой не считаем.
     */
    public static boolean isInteractSwing(EntityPlayer player) {
        long last = player.getEntityData().getLong(KEY_RC);
        return last > 0L && player.world.getTotalWorldTime() - last <= 1L;
    }

    private static void markRightClick(EntityPlayer player) {
        player.getEntityData().setLong(KEY_RC, player.world.getTotalWorldTime());
    }

    /** Вернуть к игроку все его копья в этом мире. Возвращает число копий. */
    public static int recall(EntityPlayer player) {
        if (player.world.isRemote) {
            return 0;
        }
        int count = 0;
        List<Entity> list = new ArrayList<Entity>(player.world.loadedEntityList);
        for (Entity e : list) {
            if (e instanceof EntitySpear && !e.isDead) {
                EntitySpear spear = (EntitySpear) e;
                if (player.getUniqueID().equals(spear.getOwnerId())) {
                    spear.startReturn();
                    count++;
                }
            }
        }
        if (count > 0) {
            player.world.playSound(null, player.posX, player.posY, player.posZ, SoundEvents.ENTITY_ENDERMEN_TELEPORT,
                    SoundCategory.PLAYERS, 0.4F, 1.8F);
        }
        return count;
    }

    /** ПКМ пустой рукой в воздух: событие есть только на клиенте, шлём пакет на сервер. */
    @SubscribeEvent
    public static void onRightClickEmpty(PlayerInteractEvent.RightClickEmpty event) {
        if (event.getHand() == EnumHand.MAIN_HAND && event.getWorld().isRemote) {
            WeaponMod.NETWORK.sendToServer(new RecallMessage());
        }
    }

    /** ПКМ пустой рукой по блоку (сервер). */
    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!event.getWorld().isRemote) {
            markRightClick(event.getEntityPlayer());
        }
        if (!event.getWorld().isRemote && event.getHand() == EnumHand.MAIN_HAND && event.getItemStack().isEmpty()) {
            recall(event.getEntityPlayer());
        }
    }

    /** ПКМ пустой рукой по существу (сервер). */
    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!event.getWorld().isRemote) {
            markRightClick(event.getEntityPlayer());
        }
        if (!event.getWorld().isRemote && event.getHand() == EnumHand.MAIN_HAND && event.getItemStack().isEmpty()) {
            recall(event.getEntityPlayer());
        }
    }

    /** ПКМ по существу «в точку» (торговля с жителем и т. п.). */
    @SubscribeEvent
    public static void onEntityInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        if (!event.getWorld().isRemote) {
            markRightClick(event.getEntityPlayer());
        }
    }
}
