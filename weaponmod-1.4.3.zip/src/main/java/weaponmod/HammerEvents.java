package weaponmod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Падение усиливает удар молота; после подброса молотом урон падением гасится. */
@Mod.EventBusSubscriber(modid = WeaponMod.MODID)
public class HammerEvents {

    public static final String KEY_NOFALL = "weaponmod_nofall_until";

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        DamageSource src = event.getSource();
        if (!(src.getTrueSource() instanceof EntityPlayer) || src.getImmediateSource() != src.getTrueSource()) {
            return;
        }
        if (!"player".equals(src.getDamageType())) {
            return;
        }
        EntityPlayer player = (EntityPlayer) src.getTrueSource();
        if (!(player.getHeldItemMainhand().getItem() instanceof ItemHammer)) {
            return;
        }
        float fall = Math.min(player.fallDistance, HammerTuning.FALL_BONUS_MAX_DISTANCE);
        if (fall > 1.0F) {
            event.setAmount(event.getAmount() + fall * HammerTuning.FALL_DAMAGE_PER_BLOCK);
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntityLiving() instanceof EntityPlayer)) {
            return;
        }
        EntityPlayer player = (EntityPlayer) event.getEntityLiving();
        NBTTagCompound data = player.getEntityData();
        long until = data.getLong(KEY_NOFALL);
        if (until > 0L) {
            if (player.world.getTotalWorldTime() <= until) {
                event.setDamageMultiplier(0.0F);
            }
            data.setLong(KEY_NOFALL, 0L); // защита одноразовая, как вода
        }
    }
}
