package weaponmod;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

/** Меч волн: каждый взмах посылает огненную волну, наклон чередуется «/» и «\» (две волны образуют X). */
public class ItemWaveSword extends ItemSword {

    private static final String KEY_SIDE = "weaponmod_wave_side";
    private static final String KEY_TIME = "weaponmod_wave_time";

    public ItemWaveSword(String name) {
        super(Item.ToolMaterial.DIAMOND);
        setMaxDamage(Balance.durability(Item.ToolMaterial.DIAMOND.getMaxUses()));
        setRegistryName(WeaponMod.MODID, name);
        setUnlocalizedName(WeaponMod.MODID + "." + name);
        setCreativeTab(CreativeTabs.COMBAT);
    }

    @Override
    public boolean onEntitySwing(EntityLivingBase entity, ItemStack stack) {
        if (!(entity instanceof EntityPlayer) || entity.world.isRemote) {
            return false;
        }
        EntityPlayer player = (EntityPlayer) entity;
        if (SpearEvents.isInteractSwing(player)) {
            return false; // взмах от ПКМ по блоку/существу, а не атака
        }
        World world = player.world;
        NBTTagCompound data = player.getEntityData();
        long now = world.getTotalWorldTime();
        if (now - data.getLong(KEY_TIME) < WaveTuning.COOLDOWN_TICKS) {
            return false;
        }
        data.setLong(KEY_TIME, now);

        int side = data.getInteger(KEY_SIDE) == 0 ? 1 : data.getInteger(KEY_SIDE);
        world.spawnEntity(new EntityWave(world, player, side));
        data.setInteger(KEY_SIDE, -side);

        world.playSound(null, player.posX, player.posY, player.posZ, SoundEvents.ENTITY_BLAZE_SHOOT,
                SoundCategory.PLAYERS, 0.4F, 1.6F);
        return false;
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.translateToLocal("tooltip.weaponmod.waveblade"));
    }
}
