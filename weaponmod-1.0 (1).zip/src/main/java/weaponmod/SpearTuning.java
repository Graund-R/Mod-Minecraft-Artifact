package weaponmod;

/** Все числа баланса копья в одном месте. Менять можно здесь. */
public final class SpearTuning {

    private SpearTuning() {}

    // --- ближний бой ---
    /** Добавка к урону материала в ближнем бою (дерево = 3.5 + 0 + 1 базовый). */
    public static final float MELEE_BASE_DAMAGE = 3.5F;
    /** Модификатор скорости атаки (меч = -2.4, копьё медленнее). */
    public static final double MELEE_ATTACK_SPEED = -2.6D;

    // --- заряд броска (в тиках, 20 тиков = 1 секунда) ---
    public static final int MIN_CHARGE_TICKS = 8;
    public static final int FULL_CHARGE_TICKS = 24;

    // --- полёт ---
    public static final float MIN_SPEED = 1.1F;
    public static final float MAX_SPEED = 2.8F;
    public static final float GRAVITY = 0.03F;
    /** Во сколько раз замедляется копьё, пробив одно существо. */
    public static final float PIERCE_SLOWDOWN = 0.92F;
    /** Базовый урон броска = THROW_BASE + урон материала. */
    public static final float THROW_BASE_DAMAGE = 4.0F;
    /** Множитель урона броска: слабый бросок / полный заряд. */
    public static final float THROW_MULT_MIN = 0.6F;
    public static final float THROW_MULT_MAX = 1.8F;
    /** Откид моба при попадании (доп. к ванильному). */
    public static final float THROW_KNOCKBACK_MIN = 0.35F;
    public static final float THROW_KNOCKBACK_MAX = 0.95F;

    // --- ударная волна при попадании в блок ---
    /** false = волна не наносит урон/замедление (остаётся только воронка и эффекты). */
    public static final boolean WAVE_ENABLED = true;
    public static final float WAVE_RADIUS_MIN = 2.0F;
    public static final float WAVE_RADIUS_MAX = 4.5F;
    public static final float WAVE_DAMAGE_MIN = 2.0F;
    public static final float WAVE_DAMAGE_MAX = 5.0F;
    public static final int WAVE_SLOW_TICKS_MIN = 60;
    public static final int WAVE_SLOW_TICKS_MAX = 140;
    /** Уровень замедления (0 = Замедление I, 1 = II). */
    public static final int WAVE_SLOW_LEVEL = 1;

    // --- разрушение блоков при попадании в блок (как маленький взрыв) ---
    /** false = блоки не ломаются вообще. */
    public static final boolean BLOCK_BREAK_ENABLED = true;
    /** Радиус воронки в блоках: слабый бросок / полный заряд (TNT для сравнения ~4). */
    public static final float BREAK_RADIUS_MIN = 1.2F;
    public static final float BREAK_RADIUS_MAX = 2.6F;
    /** Блоки твёрже этого не ломаются (камень 1.5, руды 3, обсидиан 50, бедрок неразрушим). */
    public static final float BREAK_MAX_HARDNESS = 3.0F;

    // --- возврат и подбор ---
    public static final float RETURN_SPEED = 1.8F;
    /** Через сколько тиков воткнутое копьё превращается в предмет на земле (6000 = 5 минут). */
    public static final int STUCK_LIFETIME_TICKS = 6000;
    /** Если копьё летит дольше этого (тики) — оно само возвращается. */
    public static final int MAX_FLIGHT_TICKS = 600;

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }
}
