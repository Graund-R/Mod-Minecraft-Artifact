package weaponmod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockButton;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockGlass;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockLever;
import net.minecraft.block.BlockPane;
import net.minecraft.block.BlockStainedGlass;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.BlockTorch;
import net.minecraft.block.BlockTrapDoor;
import net.minecraft.block.BlockWorkbench;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityHanging;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Защита от случайного разрушения: жители, ручные питомцы, рамки и постройки
 * (активные блоки: сундуки, печи, двери, кровати, верстаки, стёкла, ступени, заборы и т. п.).
 */
public final class Safety {

    private Safety() {}

    /** Общий выключатель всех защит. */
    public static final boolean ENABLED = true;
    /** Снаряды (копьё, диск, волны) пролетают сквозь жителей и питомцев не раня их. */
    public static final boolean PROTECT_ENTITIES = true;
    /** Воронки не ломают постройки и активные блоки. */
    public static final boolean PROTECT_BLOCKS = true;

    public static boolean isProtectedEntity(Entity e) {
        if (!ENABLED || !PROTECT_ENTITIES) {
            return false;
        }
        if (e instanceof EntityVillager || e instanceof EntityHanging || e instanceof EntityArmorStand) {
            return true;
        }
        if (e instanceof EntityTameable && ((EntityTameable) e).isTamed()) {
            return true;
        }
        if (e instanceof AbstractHorse && ((AbstractHorse) e).isTame()) {
            return true;
        }
        return e instanceof EntityIronGolem && ((EntityIronGolem) e).isPlayerCreated();
    }

    public static boolean isProtectedBlock(World world, BlockPos pos, IBlockState state) {
        if (!ENABLED || !PROTECT_BLOCKS) {
            return false;
        }
        if (world.getTileEntity(pos) != null) {
            return true; // сундуки, печи, таблички, спавнеры и т. д.
        }
        Block b = state.getBlock();
        return b instanceof BlockDoor || b instanceof BlockBed || b instanceof BlockWorkbench
                || b instanceof BlockFenceGate || b instanceof BlockTrapDoor || b instanceof BlockTorch
                || b instanceof BlockLadder || b instanceof BlockGlass || b instanceof BlockStainedGlass
                || b instanceof BlockPane || b instanceof BlockStairs || b instanceof BlockFence
                || b instanceof BlockCarpet || b instanceof BlockLever || b instanceof BlockButton;
    }

    /** Сколько защищённых существ в радиусе от точки. */
    public static int countProtectedEntities(World world, Vec3d c, double radius) {
        if (!ENABLED || !PROTECT_ENTITIES) {
            return 0;
        }
        AxisAlignedBB area = new AxisAlignedBB(c.x - radius, c.y - 2.0D, c.z - radius, c.x + radius, c.y + 5.0D, c.z + radius);
        int n = 0;
        for (Entity e : world.getEntitiesWithinAABB(Entity.class, area)) {
            if (isProtectedEntity(e) && e.getDistance(c.x, c.y, c.z) <= radius) {
                n++;
            }
        }
        return n;
    }

    /** Есть ли защищённые блоки в шаре радиуса r (и сколько, до 999). */
    public static int countProtectedBlocks(World world, Vec3d c, double r) {
        if (!ENABLED || !PROTECT_BLOCKS) {
            return 0;
        }
        BlockPos origin = new BlockPos(c);
        int ir = (int) Math.ceil(r);
        int n = 0;
        for (int dx = -ir; dx <= ir; dx++) {
            for (int dy = -ir; dy <= ir; dy++) {
                for (int dz = -ir; dz <= ir; dz++) {
                    if (dx * dx + dy * dy + dz * dz > r * r) {
                        continue;
                    }
                    BlockPos p = origin.add(dx, dy, dz);
                    IBlockState st = world.getBlockState(p);
                    if (!st.getBlock().isAir(st, world, p) && isProtectedBlock(world, p, st)) {
                        if (++n >= 999) {
                            return n;
                        }
                    }
                }
            }
        }
        return n;
    }

    /** Рядом (в кубе радиуса r) есть защищённый блок: огонь здесь ставить нельзя. */
    public static boolean nearProtectedBlock(World world, BlockPos pos, int r) {
        if (!ENABLED || !PROTECT_BLOCKS) {
            return false;
        }
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos p = pos.add(dx, dy, dz);
                    IBlockState st = world.getBlockState(p);
                    if (!st.getBlock().isAir(st, world, p) && isProtectedBlock(world, p, st)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
