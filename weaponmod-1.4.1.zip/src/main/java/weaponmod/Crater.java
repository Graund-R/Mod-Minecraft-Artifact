package weaponmod;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.BlockEvent;

import javax.annotation.Nullable;

/** Воронка в блоках вокруг точки (как маленький взрыв) с защитой миров и чужими запретами. */
public final class Crater {

    private Crater() {}

    public static int blast(World world, Vec3d c, float r, float maxHardness) {
        return blast(world, c, r, maxHardness, null);
    }

    /**
     * @param breaker игрок-владелец: для каждого блока шлётся обычное событие разрушения,
     *                поэтому защиты других модов (стены кармана и т. п.) его отменяют.
     */
    public static int blast(World world, Vec3d c, float r, float maxHardness, @Nullable EntityPlayer breaker) {
        if (Protection.isProtectedWorld(world)) {
            return 0;
        }
        BlockPos origin = new BlockPos(c);
        int ir = MathHelper.ceil(r);
        int broken = 0;
        for (int dx = -ir; dx <= ir; dx++) {
            for (int dy = -ir; dy <= ir; dy++) {
                for (int dz = -ir; dz <= ir; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d > r) {
                        continue;
                    }
                    if (d > r * 0.6D && world.rand.nextFloat() < (float) ((d - r * 0.6D) / (r * 0.4D)) * 0.6F) {
                        continue;
                    }
                    BlockPos bp = origin.add(dx, dy, dz);
                    IBlockState st = world.getBlockState(bp);
                    if (st.getBlock().isAir(st, world, bp) || st.getMaterial().isLiquid()) {
                        continue;
                    }
                    float hardness = st.getBlockHardness(world, bp);
                    if (hardness < 0.0F || hardness > maxHardness) {
                        continue;
                    }
                    if (world.getTileEntity(bp) != null || Safety.isProtectedBlock(world, bp, st)) {
                        continue; // сундуки, печи, двери, кровати, стёкла и т. п. не трогаем
                    }
                    if (breaker != null && world instanceof WorldServer) {
                        BlockEvent.BreakEvent event = new BlockEvent.BreakEvent(world, bp, st, breaker);
                        if (MinecraftForge.EVENT_BUS.post(event)) {
                            continue;
                        }
                    }
                    world.destroyBlock(bp, true);
                    broken++;
                }
            }
        }
        return broken;
    }
}
