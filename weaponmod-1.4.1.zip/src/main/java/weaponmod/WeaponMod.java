package weaponmod;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = WeaponMod.MODID, name = "Weapon Mod", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class WeaponMod {

    public static final String MODID = "weaponmod";

    @Mod.Instance(MODID)
    public static WeaponMod instance;

    public static SimpleNetworkWrapper NETWORK;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        NETWORK = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        NETWORK.registerMessage(RecallMessage.Handler.class, RecallMessage.class, 0, Side.SERVER);

        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "spear"), EntitySpear.class, "spear", 0, this, 64, 2, true);
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "disc"), EntityDisc.class, "disc", 1, this, 64, 2, true);
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "wave"), EntityWave.class, "wave", 2, this, 64, 2, true);

        if (event.getSide() == Side.CLIENT) {
            ClientHandler.registerRenderers();
        }
    }
}
