package weaponmod;

import net.minecraft.world.DimensionType;
import net.minecraft.world.World;

/** Где оружие не должно ломать блоки и поджигать (например, карманное измерение мода «Карманный»). */
public final class Protection {

    private Protection() {}

    /** ID измерения кармана в моде «Карманный». */
    public static final int POCKET_DIM_ID = 100;

    public static boolean isProtectedWorld(World world) {
        if (world.provider.getDimension() == POCKET_DIM_ID) {
            return true;
        }
        DimensionType type = world.provider.getDimensionType();
        return type != null && "pocket".equals(type.getName());
    }
}
