package weaponmod;

import com.google.common.collect.Multimap;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Молот Тора. Взмах (ЛКМ) бьёт молнией туда, куда смотришь. Удержание ПКМ заряжает мощный удар.
 * Урон растёт с высотой падения; удар под ноги подбрасывает и гасит падение.
 */
public class ItemHammer extends Item {

    public ItemHammer(String name) {
        setRegistryName(WeaponMod.MODID, name);
        setUnlocalizedName(WeaponMod.MODID + "." + name);
        setMaxStackSize(1);
        setMaxDamage(HammerTuning.MAX_USES);
        setCreativeTab(CreativeTabs.COMBAT);
    }

    @Override
    public Multimap<String, AttributeModifier> getItemAttributeModifiers(EntityEquipmentSlot slot) {
        Multimap<String, AttributeModifier> map = super.getItemAttributeModifiers(slot);
        if (slot == EntityEquipmentSlot.MAINHAND) {
            map.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", (double) HammerTuning.MELEE_DAMAGE, 0));
            map.put(SharedMonsterAttributes.ATTACK_SPEED.getName(),
                    new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", HammerTuning.MELEE_ATTACK_SPEED, 0));
        }
        return map;
    }

    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        stack.damageItem(1, attacker);
        return true;
    }

    @Override
    public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos, EntityLivingBase entityLiving) {
        return true;
    }

    @Override
    public boolean canDestroyBlockInCreative(World world, BlockPos pos, ItemStack stack, EntityPlayer player) {
        return false;
    }

    @Override
    public boolean isFull3D() {
        return true;
    }

    // ---------- заряженный удар (удержание ПКМ) ----------

    @Override
    public EnumAction getItemUseAction(ItemStack stack) {
        return EnumAction.NONE; // поза заряда рисуется в ClientEvents
    }

    @Override
    public int getMaxItemUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        ItemStack off = player.getHeldItemOffhand();
        if (hand == EnumHand.MAIN_HAND && player.isSneaking() && !off.isEmpty() && off.getItem().isShield(off, player)) {
            return new ActionResult<ItemStack>(EnumActionResult.PASS, stack);
        }
        player.setActiveHand(hand);
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    public void onPlayerStoppedUsing(ItemStack stack, World world, EntityLivingBase entity, int timeLeft) {
        if (world.isRemote || !(entity instanceof EntityPlayer)) {
            return;
        }
        EntityPlayer player = (EntityPlayer) entity;
        int charge = getMaxItemUseDuration(stack) - timeLeft;
        if (charge < HammerTuning.CHARGE_MIN_TICKS || player.getCooldownTracker().hasCooldown(this)) {
            return;
        }
        float power = Math.min(1.0F, (float) charge / (float) HammerTuning.CHARGE_FULL_TICKS);
        if (strike(player, power, true)) {
            player.getCooldownTracker().setCooldown(this, HammerTuning.CHARGED_COOLDOWN);
            stack.damageItem(3, player);
        }
    }

    // ---------- обычный взмах ----------

    @Override
    public boolean onEntitySwing(EntityLivingBase entity, ItemStack stack) {
        if (!(entity instanceof EntityPlayer) || entity.world.isRemote) {
            return false;
        }
        EntityPlayer player = (EntityPlayer) entity;
        if (player.getCooldownTracker().hasCooldown(this)) {
            return false;
        }
        if (strike(player, 0.0F, false)) {
            player.getCooldownTracker().setCooldown(this, HammerTuning.STRIKE_COOLDOWN);
            stack.damageItem(1, player);
        }
        return false;
    }

    private static class Target {
        final Vec3d point;
        final boolean onBlock;
        final double dist;

        Target(Vec3d point, boolean onBlock, double dist) {
            this.point = point;
            this.onBlock = onBlock;
            this.dist = dist;
        }
    }

    private Target findTarget(EntityPlayer player, double reach) {
        World world = player.world;
        Vec3d eye = player.getPositionEyes(1.0F);
        Vec3d end = eye.add(player.getLookVec().scale(reach));

        RayTraceResult blockHit = world.rayTraceBlocks(eye, end, false, true, false);
        boolean hasBlock = blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK;
        double best = hasBlock ? eye.distanceTo(blockHit.hitVec) : reach;

        Entity target = null;
        for (Entity e : world.getEntitiesWithinAABBExcludingEntity(player, new AxisAlignedBB(eye, end).grow(1.0D))) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive()) {
                continue;
            }
            AxisAlignedBB box = e.getEntityBoundingBox().grow(0.4D);
            RayTraceResult r = box.calculateIntercept(eye, end);
            double d = -1.0D;
            if (r != null) {
                d = eye.distanceTo(r.hitVec);
            } else if (box.contains(eye)) {
                d = 0.0D;
            }
            if (d >= 0.0D && d < best) {
                best = d;
                target = e;
            }
        }
        if (target != null) {
            return new Target(new Vec3d(target.posX, target.posY, target.posZ), false, best);
        }
        if (hasBlock) {
            return new Target(blockHit.hitVec, true, best);
        }
        return null;
    }

    /** Молния(и) в точку взгляда, воронка при касании блока, подброс при ударе под ноги. */
    private boolean strike(EntityPlayer player, float power, boolean charged) {
        World world = player.world;
        Target t = findTarget(player, HammerTuning.STRIKE_RADIUS);
        if (t == null) {
            return false;
        }
        Vec3d look = player.getLookVec();
        float fall = Math.min(player.fallDistance, HammerTuning.FALL_BONUS_MAX_DISTANCE);
        float damage = HammerTuning.BOLT_DAMAGE * (1.0F + fall / 15.0F) * (1.0F + power * HammerTuning.CHARGED_DAMAGE_BONUS);

        Vec3d self = new Vec3d(player.posX, player.posY + player.height * 0.5D, player.posZ);
        boolean effect = false;

        // молния не бьёт ближе 2 блоков от игрока (в т. ч. под ногами)
        if (t.point.distanceTo(self) >= HammerTuning.MIN_LIGHTNING_DISTANCE) {
            lightning(player, t.point, damage);
            effect = true;
        }
        if (charged) {
            int bolts = 1 + (int) (power * (HammerTuning.CHARGED_BOLTS_MAX - 1));
            for (int i = 1; i < bolts; i++) {
                double a = world.rand.nextDouble() * Math.PI * 2.0D;
                double d = 1.5D + world.rand.nextDouble() * HammerTuning.CHARGED_BOLT_SPREAD;
                Vec3d p = new Vec3d(t.point.x + Math.cos(a) * d, t.point.y, t.point.z + Math.sin(a) * d);
                if (p.distanceTo(self) >= HammerTuning.MIN_LIGHTNING_DISTANCE) {
                    lightning(player, p, damage);
                    effect = true;
                }
            }
        }

        boolean contact = t.onBlock && t.dist <= HammerTuning.CONTACT_RANGE;
        if (contact && HammerTuning.BLOCK_BREAK_ENABLED) {
            effect = true;
            float radius = HammerTuning.CRATER_RADIUS * (1.0F + Math.min(fall, 30.0F) / 20.0F) * (1.0F + power);
            radius = Math.min(radius, HammerTuning.CRATER_MAX_RADIUS);
            Vec3d c = t.point.add(look.scale(0.3D));
            int broken = Crater.blast(world, c, radius, HammerTuning.CRATER_MAX_HARDNESS);
            if (broken > 0 && world instanceof WorldServer) {
                ((WorldServer) world).spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, c.x, c.y, c.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }

        // удар под ноги: подброс и защита от падения
        if (contact && look.y < HammerTuning.UNDERFOOT_LOOK_Y) {
            double vy = HammerTuning.LAUNCH_BASE + fall * HammerTuning.LAUNCH_PER_FALL;
            vy *= 1.0D + power * 0.5D;
            player.motionY = Math.min(vy, HammerTuning.LAUNCH_MAX);
            player.velocityChanged = true;
            player.fallDistance = 0.0F;
            player.getEntityData().setLong(HammerEvents.KEY_NOFALL,
                    world.getTotalWorldTime() + HammerTuning.NOFALL_WINDOW);
            effect = true;
        }
        return effect;
    }

    /** Молния без урона владельцу: разряд визуальный, урон наносим вручную всем, кроме игрока. */
    private void lightning(EntityPlayer owner, Vec3d p, float damage) {
        World world = owner.world;
        EntityLightningBolt bolt = new EntityLightningBolt(world, p.x, p.y, p.z, true);
        world.addWeatherEffect(bolt);
        double r = HammerTuning.LIGHTNING_AOE;
        AxisAlignedBB area = new AxisAlignedBB(p.x - r, p.y - 2.0D, p.z - r, p.x + r, p.y + 5.0D, p.z + r);
        DamageSource src = new EntityDamageSource("lightningBolt", owner);
        for (Entity e : world.getEntitiesWithinAABBExcludingEntity(bolt, area)) {
            if (e == owner || !(e instanceof EntityLivingBase) || !e.isEntityAlive()) {
                continue;
            }
            e.attackEntityFrom(src, damage);
            e.onStruckByLightning(bolt); // поджог, заряд крипера и т. д.
        }
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.translateToLocal("tooltip.weaponmod.hammer"));
        tooltip.add(I18n.translateToLocal("tooltip.weaponmod.hammer2"));
    }
}
