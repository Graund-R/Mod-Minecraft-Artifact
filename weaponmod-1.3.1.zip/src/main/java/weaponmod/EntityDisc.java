package weaponmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Летящий метательный диск: вперёд, рикошеты от блоков, потом назад к владельцу. */
public class EntityDisc extends Entity {

    public static final int OUT = 0;
    public static final int BACK = 1;

    private static final DataParameter<ItemStack> STACK = EntityDataManager.createKey(EntityDisc.class, DataSerializers.ITEM_STACK);
    private static final DataParameter<Byte> STATE = EntityDataManager.createKey(EntityDisc.class, DataSerializers.BYTE);

    private UUID ownerId;
    private boolean creativeThrow;
    /** Куда вернуть: слот хотбара 0..8, -2 = левая рука, -1 = просто в инвентарь. */
    private int slot = -1;
    private float damage = 5.0F;
    private double range = 8.0D;
    private double travelled;
    private int bounces;
    private int ticks;
    private final Set<Integer> hitIds = new HashSet<Integer>();

    public EntityDisc(World world) {
        super(world);
        setSize(0.5F, 0.5F);
    }

    public EntityDisc(World world, EntityPlayer owner, ItemStack stack, int slot, float damage, double range, boolean creative) {
        this(world);
        this.ownerId = owner.getUniqueID();
        this.slot = slot;
        this.damage = damage;
        this.range = range;
        this.creativeThrow = creative;
        setStack(stack);

        setLocationAndAngles(owner.posX, owner.posY + owner.getEyeHeight(), owner.posZ, owner.rotationYaw, owner.rotationPitch);
        float yawR = owner.rotationYaw * 0.017453292F;
        float pitchR = owner.rotationPitch * 0.017453292F;
        double dx = -MathHelper.sin(yawR) * MathHelper.cos(pitchR);
        double dy = -MathHelper.sin(pitchR);
        double dz = MathHelper.cos(yawR) * MathHelper.cos(pitchR);
        setPosition(owner.posX + dx * 0.6D, owner.posY + owner.getEyeHeight() - 0.2D + dy * 0.6D, owner.posZ + dz * 0.6D);
        this.motionX = dx * DiscTuning.SPEED;
        this.motionY = dy * DiscTuning.SPEED;
        this.motionZ = dz * DiscTuning.SPEED;
    }

    @Override
    protected void entityInit() {
        this.dataManager.register(STACK, ItemStack.EMPTY);
        this.dataManager.register(STATE, Byte.valueOf((byte) OUT));
    }

    public ItemStack getStack() {
        return this.dataManager.get(STACK);
    }

    private void setStack(ItemStack s) {
        this.dataManager.set(STACK, s);
    }

    public int getState() {
        return this.dataManager.get(STATE).intValue();
    }

    private void setState(int s) {
        this.dataManager.set(STATE, Byte.valueOf((byte) s));
    }

    private EntityPlayer getOwner() {
        return ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
    }

    private void startBack() {
        if (getState() != BACK) {
            setState(BACK);
            hitIds.clear();
            ticks = 0;
            this.velocityChanged = true;
        }
    }

    // ---------- тик ----------

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            this.posX += this.motionX;
            this.posY += this.motionY;
            this.posZ += this.motionZ;
            setPosition(this.posX, this.posY, this.posZ);
            return;
        }
        ticks++;
        if (getState() == OUT) {
            tickOut();
        } else {
            tickBack();
        }
    }

    private void tickOut() {
        if (ticks > DiscTuning.MAX_OUT_TICKS) {
            startBack();
            return;
        }
        Vec3d pos = new Vec3d(this.posX, this.posY, this.posZ);
        Vec3d motion = new Vec3d(this.motionX, this.motionY, this.motionZ);
        Vec3d end = pos.add(motion);

        RayTraceResult blockHit = world.rayTraceBlocks(pos, end, false, true, false);
        boolean hitBlock = blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK;
        hitAlong(pos, hitBlock ? blockHit.hitVec : end);

        if (hitBlock) {
            bounce(blockHit, motion);
            return;
        }

        setPosition(end.x, end.y, end.z);
        if (DiscTuning.IGNITE_BLOCKS && ticks % DiscTuning.TRAIL_INTERVAL == 0) {
            ignite(new BlockPos(this.posX, this.posY, this.posZ));
        }
        travelled += motion.lengthVector();
        if (travelled >= range) {
            startBack();
        }
    }

    private void bounce(RayTraceResult hit, Vec3d motion) {
        EnumFacing f = hit.sideHit;
        bounces++;
        if (f == null || bounces > DiscTuning.MAX_BOUNCES) {
            startBack();
            return;
        }
        Vec3d n = new Vec3d(f.getFrontOffsetX(), f.getFrontOffsetY(), f.getFrontOffsetZ());
        double dot = motion.dotProduct(n);
        Vec3d r = motion.subtract(n.scale(2.0D * dot));

        // с каждым рикошетом диск сильнее и наводится на ближайшего врага
        damage *= DiscTuning.BOUNCE_DAMAGE_MULT;
        EntityLivingBase foe = findNearestEnemy(hit.hitVec);
        if (foe != null) {
            Vec3d to = new Vec3d(foe.posX, foe.posY + foe.height * 0.5D, foe.posZ).subtract(hit.hitVec);
            double len = to.lengthVector();
            if (len > 0.5D) {
                Vec3d dir = to.scale(1.0D / len);
                if (dir.dotProduct(n) > 0.15D) { // цель по эту сторону от поверхности
                    r = dir.scale((double) DiscTuning.SPEED);
                }
            }
        }

        setPosition(hit.hitVec.x + n.x * 0.3D, hit.hitVec.y + n.y * 0.3D, hit.hitVec.z + n.z * 0.3D);
        this.motionX = r.x;
        this.motionY = r.y;
        this.motionZ = r.z;
        this.velocityChanged = true;
        range += DiscTuning.BOUNCE_RANGE_BONUS;
        hitIds.clear();
        ignite(hit.getBlockPos().offset(f));

        world.playSound(null, hit.hitVec.x, hit.hitVec.y, hit.hitVec.z, SoundEvents.ENTITY_ARROW_HIT,
                SoundCategory.PLAYERS, 0.8F, 1.7F);
        if (world instanceof WorldServer) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.CRIT, hit.hitVec.x, hit.hitVec.y, hit.hitVec.z,
                    8, 0.15D, 0.15D, 0.15D, 0.15D);
        }
    }

    /** Поджигает воздух рядом с твёрдой/горючей опорой (как огниво). */
    private void ignite(BlockPos pos) {
        if (DiscTuning.IGNITE_BLOCKS && world.isAirBlock(pos) && Blocks.FIRE.canPlaceBlockAt(world, pos)) {
            world.setBlockState(pos, Blocks.FIRE.getDefaultState());
        }
    }

    private EntityLivingBase findNearestEnemy(Vec3d c) {
        double rad = DiscTuning.HOMING_RADIUS;
        AxisAlignedBB area = new AxisAlignedBB(c.x - rad, c.y - rad, c.z - rad, c.x + rad, c.y + rad, c.z + rad);
        EntityLivingBase best = null;
        double bestD = rad * rad;
        for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, area)) {
            if (!(e instanceof IMob) || !e.isEntityAlive()) {
                continue;
            }
            double d = e.getDistanceSq(c.x, c.y, c.z);
            if (d < bestD) {
                bestD = d;
                best = e;
            }
        }
        return best;
    }

    private void tickBack() {
        EntityPlayer owner = getOwner();
        if (owner == null || owner.isDead || ticks > DiscTuning.MAX_BACK_TICKS) {
            dropAsItem();
            return;
        }
        Vec3d target = new Vec3d(owner.posX, owner.posY + owner.height * 0.6D, owner.posZ);
        Vec3d to = target.subtract(this.posX, this.posY, this.posZ);
        double dist = to.lengthVector();
        if (dist < 1.4D) {
            giveToOwner(owner);
            return;
        }
        double spd = Math.min((double) DiscTuning.RETURN_SPEED, dist);
        Vec3d v = to.scale(spd / dist);
        this.motionX = v.x;
        this.motionY = v.y;
        this.motionZ = v.z;
        Vec3d pos = new Vec3d(this.posX, this.posY, this.posZ);
        Vec3d end = pos.add(v);
        hitAlong(pos, end);
        setPosition(end.x, end.y, end.z);
        this.velocityChanged = true;
    }

    // ---------- попадания по существам ----------

    private void hitAlong(Vec3d start, Vec3d end) {
        EntityPlayer owner = getOwner();
        List<Entity> nearby = world.getEntitiesWithinAABBExcludingEntity(this, new AxisAlignedBB(start, end).grow(1.0D));
        List<Hit> hits = new ArrayList<Hit>();
        for (Entity e : nearby) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive() || e == owner || hitIds.contains(e.getEntityId())) {
                continue;
            }
            AxisAlignedBB box = e.getEntityBoundingBox().grow(0.3D);
            RayTraceResult r = box.calculateIntercept(start, end);
            if (r != null) {
                hits.add(new Hit((EntityLivingBase) e, start.squareDistanceTo(r.hitVec)));
            } else if (box.contains(start)) {
                hits.add(new Hit((EntityLivingBase) e, 0.0D));
            }
        }
        Collections.sort(hits);
        for (Hit h : hits) {
            hitEntity(h.entity);
        }
    }

    private static class Hit implements Comparable<Hit> {
        final EntityLivingBase entity;
        final double dist;

        Hit(EntityLivingBase entity, double dist) {
            this.entity = entity;
            this.dist = dist;
        }

        @Override
        public int compareTo(Hit o) {
            return Double.compare(this.dist, o.dist);
        }
    }

    private void hitEntity(EntityLivingBase target) {
        hitIds.add(target.getEntityId());
        Entity owner = getOwner();
        boolean hurt = target.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), damage);
        if (hurt) {
            double h = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (h > 1.0E-4D) {
                target.addVelocity(this.motionX / h * DiscTuning.KNOCKBACK, 0.08D, this.motionZ / h * DiscTuning.KNOCKBACK);
            }
            world.playSound(null, target.posX, target.posY, target.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG,
                    SoundCategory.PLAYERS, 0.7F, 1.3F);
        }
    }

    // ---------- возврат в руку ----------

    private void giveToOwner(EntityPlayer owner) {
        if (!creativeThrow) {
            ItemStack s = getStack().copy();
            boolean placed = false;
            if (slot >= 0 && slot < 9 && owner.inventory.getStackInSlot(slot).isEmpty()) {
                owner.inventory.setInventorySlotContents(slot, s);
                placed = true;
            } else if (slot == -2 && owner.getHeldItemOffhand().isEmpty()) {
                owner.setHeldItem(EnumHand.OFF_HAND, s);
                placed = true;
            }
            if (!placed && !owner.inventory.addItemStackToInventory(s)) {
                owner.dropItem(s, false);
            }
        }
        world.playSound(null, owner.posX, owner.posY, owner.posZ, SoundEvents.ENTITY_ITEM_PICKUP,
                SoundCategory.PLAYERS, 0.4F, 1.4F);
        setDead();
    }

    private void dropAsItem() {
        if (!creativeThrow && !getStack().isEmpty()) {
            entityDropItem(getStack().copy(), 0.0F);
        }
        setDead();
    }

    // ---------- сохранение ----------

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {
        if (c.hasUniqueId("Owner")) {
            this.ownerId = c.getUniqueId("Owner");
        }
        setStack(new ItemStack(c.getCompoundTag("Stack")));
        setState(c.getByte("State"));
        this.creativeThrow = c.getBoolean("Creative");
        this.slot = c.getInteger("Slot");
        this.damage = c.getFloat("Damage");
        this.range = c.getDouble("Range");
        this.travelled = c.getDouble("Travelled");
        this.bounces = c.getInteger("Bounces");
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {
        if (ownerId != null) {
            c.setUniqueId("Owner", ownerId);
        }
        c.setTag("Stack", getStack().writeToNBT(new NBTTagCompound()));
        c.setByte("State", (byte) getState());
        c.setBoolean("Creative", creativeThrow);
        c.setInteger("Slot", slot);
        c.setFloat("Damage", damage);
        c.setDouble("Range", range);
        c.setDouble("Travelled", travelled);
        c.setInteger("Bounces", bounces);
    }
}
