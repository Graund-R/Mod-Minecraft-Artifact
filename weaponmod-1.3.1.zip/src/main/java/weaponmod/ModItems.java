package weaponmod;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = WeaponMod.MODID)
public class ModItems {

    public static final ItemSpear WOODEN_SPEAR = new ItemSpear("wooden_spear", Item.ToolMaterial.WOOD);
    public static final ItemSpear STONE_SPEAR = new ItemSpear("stone_spear", Item.ToolMaterial.STONE);
    public static final ItemSpear IRON_SPEAR = new ItemSpear("iron_spear", Item.ToolMaterial.IRON);
    public static final ItemSpear GOLDEN_SPEAR = new ItemSpear("golden_spear", Item.ToolMaterial.GOLD);
    public static final ItemSpear DIAMOND_SPEAR = new ItemSpear("diamond_spear", Item.ToolMaterial.DIAMOND);

    public static final ItemSpear[] SPEARS = {WOODEN_SPEAR, STONE_SPEAR, IRON_SPEAR, GOLDEN_SPEAR, DIAMOND_SPEAR};

    public static final ItemDisc IRON_DISC = new ItemDisc("iron_throwing_disc", Item.ToolMaterial.IRON);
    public static final ItemDisc GOLDEN_DISC = new ItemDisc("golden_throwing_disc", Item.ToolMaterial.GOLD);
    public static final ItemDisc DIAMOND_DISC = new ItemDisc("diamond_throwing_disc", Item.ToolMaterial.DIAMOND);

    public static final ItemHammer THORS_HAMMER = new ItemHammer("thors_hammer");

    public static final ItemDisc[] DISCS = {IRON_DISC, GOLDEN_DISC, DIAMOND_DISC};

    public static final ItemHammer THOR_HAMMER = new ItemHammer("thor_hammer");
    public static final ItemWaveSword WAVE_BLADE = new ItemWaveSword("wave_blade");

    public static final Item[] SINGLES = {THOR_HAMMER, WAVE_BLADE};

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(SPEARS);
        event.getRegistry().registerAll(DISCS);
        event.getRegistry().registerAll(SINGLES);
        event.getRegistry().register(THORS_HAMMER);
    }
}
