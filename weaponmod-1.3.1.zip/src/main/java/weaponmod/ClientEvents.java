package weaponmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Анимации от первого лица:
 * копьё: заряд (отвод назад и вздрагивание) и удар как выпад вперёд;
 * молот: подъём над головой при заряде.
 */
@Mod.EventBusSubscriber(modid = WeaponMod.MODID, value = Side.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onRenderHand(RenderSpecificHandEvent event) {
        if (event.getHand() != EnumHand.MAIN_HAND) {
            return;
        }
        ItemStack stack = event.getItemStack();
        boolean spear = stack.getItem() instanceof ItemSpear;
        boolean hammer = stack.getItem() instanceof ItemHammer;
        if (!spear && !hammer) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP player = mc.player;
        if (player == null) {
            return;
        }
        float pt = event.getPartialTicks();
        boolean charging = player.isHandActive() && player.getActiveHand() == EnumHand.MAIN_HAND;
        float swing = event.getSwingProgress();
        if (!charging && (hammer || swing <= 0.0F)) {
            return; // обычная поза и обычный взмах молота оставляем ванильными
        }

        boolean right = player.getPrimaryHand() == EnumHandSide.RIGHT;
        float s = right ? 1.0F : -1.0F;

        GlStateManager.pushMatrix();
        GlStateManager.translate(s * 0.56F, -0.52F + event.getEquipProgress() * -0.6F, -0.72F);

        if (charging) {
            float ticks = stack.getMaxItemUseDuration() - (player.getItemInUseCount() - pt + 1.0F);
            float full = spear ? (float) SpearTuning.FULL_CHARGE_TICKS : (float) HammerTuning.CHARGE_FULL_TICKS;
            float c = MathHelper.clamp(ticks / full, 0.0F, 1.0F);
            float t = player.ticksExisted + pt;
            if (spear) {
                GlStateManager.translate(s * -0.05F * c, 0.08F * c, 0.45F * c);
                GlStateManager.rotate(-30.0F * c, 1.0F, 0.0F, 0.0F);
                GlStateManager.rotate(s * 12.0F * c, 0.0F, 1.0F, 0.0F);
            } else {
                GlStateManager.translate(s * -0.1F * c, 0.35F * c, 0.1F * c);
                GlStateManager.rotate(-55.0F * c, 1.0F, 0.0F, 0.0F);
            }
            if (c >= 1.0F) {
                GlStateManager.translate(MathHelper.sin(t * 2.7F) * 0.012F, MathHelper.sin(t * 3.1F) * 0.012F, 0.0F);
            }
        } else {
            // выпад копьём вперёд вместо взмаха мечом
            float f = MathHelper.sin(MathHelper.sqrt(swing) * (float) Math.PI);
            GlStateManager.translate(0.0F, 0.06F * f, -1.1F * f);
            GlStateManager.rotate(12.0F * f, 1.0F, 0.0F, 0.0F);
        }

        mc.getItemRenderer().renderItemSide(player, stack,
                right ? ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND
                      : ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND, !right);
        GlStateManager.popMatrix();
        event.setCanceled(true);
    }
}
