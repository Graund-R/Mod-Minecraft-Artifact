package weaponmod;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class EntitySpear extends Entity {

    public static final int FLYING = 0;
    public static final int STUCK = 1;
    public static final int RETURNING = 2;

    /** Расстояние от центра сущности до острия (визуально копьё ~2 блока). */
    private static final double TIP = 0.9D;

    private static final DataParameter<ItemStack> STACK = EntityDataManager.createKey(EntitySpear.class, DataSerializers.ITEM_STACK);
    private static final DataParameter<Byte> STATE = EntityDataManager.createKey(EntitySpear.class, DataSerializers.BYTE);

    private UUID ownerId;
    private float power = 1.0F;
    private boolean creativeThrow;
    private boolean noWave;
    private int stuckTicks;
    private int flightTicks;
    private final Set<Integer> hitIds = new HashSet<Integer>();

    public EntitySpear(World world) {
        super(world);
        setSize(0.4F, 0.4F);
    }

    public EntitySpear(World world, EntityPlayer owner, ItemStack stack, float power, boolean creative) {
        this(world);
        this.ownerId = owner.getUniqueID();
        this.power = power;
        this.creativeThrow = creative;
        setStack(stack);

        setLocationAndAngles(owner.posX, owner.posY + owner.getEyeHeight(), owner.posZ, owner.rotationYaw, owner.rotationPitch);
        float yawR = owner.rotationYaw * 0.017453292F;
        float pitchR = owner.rotationPitch * 0.017453292F;
        double dx = -MathHelper.sin(yawR) * MathHelper.cos(pitchR);
        double dy = -MathHelper.sin(pitchR);
        double dz = MathHelper.cos(yawR) * MathHelper.cos(pitchR);

        setPosition(owner.posX + dx * 0.6D, owner.posY + owner.getEyeHeight() - 0.15D + dy * 0.6D, owner.posZ + dz * 0.6D);

        float speed = SpearTuning.lerp(SpearTuning.MIN_SPEED, SpearTuning.MAX_SPEED, power);
        this.motionX = dx * speed;
        this.motionY = dy * speed;
        this.motionZ = dz * speed;
        updateRotationFromMotion();
        this.prevRotationYaw = this.rotationYaw;
        this.prevRotationPitch = this.rotationPitch;
    }

    @Override
    protected void entityInit() {
        this.dataManager.register(STACK, ItemStack.EMPTY);
        this.dataManager.register(STATE, Byte.valueOf((byte) FLYING));
    }

    // ---------- доступ ----------

    public ItemStack getStack() {
        return this.dataManager.get(STACK);
    }

    private void setStack(ItemStack stack) {
        this.dataManager.set(STACK, stack);
    }

    public int getState() {
        return this.dataManager.get(STATE).intValue();
    }

    private void setState(int state) {
        this.dataManager.set(STATE, Byte.valueOf((byte) state));
    }

    public UUID getOwnerId() {
        return ownerId;
    }

    private EntityPlayer getOwner() {
        return ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
    }

    /** Вызывается только на сервере: копьё летит обратно к владельцу. */
    public void startReturn() {
        if (getState() != RETURNING) {
            setState(RETURNING);
            hitIds.clear();
            this.velocityChanged = true;
        }
    }

    // ---------- основной тик ----------

    @Override
    public void onUpdate() {
        super.onUpdate();

        int state = getState();
        if (state == STUCK) {
            if (!world.isRemote) {
                tickStuck();
            }
            return;
        }

        if (state == RETURNING) {
            if (!world.isRemote) {
                tickReturning();
            } else {
                advance();
            }
            return;
        }

        // FLYING
        if (!world.isRemote) {
            tickFlying();
        } else {
            advance();
            applyFlightPhysics();
        }
    }

    /** Простое движение без столкновений (клиент и сервер). */
    private void advance() {
        this.posX += this.motionX;
        this.posY += this.motionY;
        this.posZ += this.motionZ;
        setPosition(this.posX, this.posY, this.posZ);
        updateRotationFromMotion();
        wrapRotation();
    }

    private void tickFlying() {
        flightTicks++;
        if (flightTicks > SpearTuning.MAX_FLIGHT_TICKS || this.posY < -20.0D) {
            startReturn();
            return;
        }

        Vec3d motion = new Vec3d(this.motionX, this.motionY, this.motionZ);
        double speed = motion.lengthVector();
        Vec3d dir = speed > 1.0E-4D ? motion.scale(1.0D / speed) : new Vec3d(0.0D, -1.0D, 0.0D);
        Vec3d tip = new Vec3d(this.posX, this.posY, this.posZ).add(dir.scale(TIP));
        Vec3d end = tip.add(motion);

        RayTraceResult blockHit = world.rayTraceBlocks(tip, end, false, true, false);
        Vec3d entityEnd = (blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK) ? blockHit.hitVec : end;

        // существа вдоль пути (пробиваем всех по порядку)
        EntityPlayer owner = getOwner();
        List<Entity> nearby = world.getEntitiesWithinAABBExcludingEntity(this, new AxisAlignedBB(tip, entityEnd).grow(1.0D));
        List<Hit> hits = new ArrayList<Hit>();
        for (Entity e : nearby) {
            if (!(e instanceof EntityLivingBase) || !e.isEntityAlive() || e == owner || hitIds.contains(e.getEntityId())) {
                continue;
            }
            AxisAlignedBB box = e.getEntityBoundingBox().grow(0.3D);
            RayTraceResult r = box.calculateIntercept(tip, entityEnd);
            if (r != null) {
                hits.add(new Hit((EntityLivingBase) e, tip.squareDistanceTo(r.hitVec)));
            } else if (box.contains(tip)) {
                hits.add(new Hit((EntityLivingBase) e, 0.0D));
            }
        }
        Collections.sort(hits);
        for (Hit h : hits) {
            hitEntity(h.entity);
        }

        if (blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK) {
            stickInBlock(blockHit, dir);
            return;
        }

        advance();
        applyFlightPhysics();
    }

    /** Сопротивление воздуха/воды и гравитация (одинаково на клиенте и сервере). */
    private void applyFlightPhysics() {
        this.motionX *= 0.99D;
        this.motionY *= 0.99D;
        this.motionZ *= 0.99D;
        if (this.isInWater()) {
            this.motionX *= 0.8D;
            this.motionY *= 0.8D;
            this.motionZ *= 0.8D;
        }
        this.motionY -= SpearTuning.GRAVITY;
    }

    private static class Hit implements Comparable<Hit> {
        final EntityLivingBase entity;
        final double dist;

        Hit(EntityLivingBase entity, double dist) {
            this.entity = entity;
            this.dist = dist;
        }

        @Override
        public int compareTo(Hit o) {
            return Double.compare(this.dist, o.dist);
        }
    }

    private float getThrowDamage() {
        float base = 5.0F;
        ItemStack s = getStack();
        if (s.getItem() instanceof ItemSpear) {
            base = ((ItemSpear) s.getItem()).getThrowBaseDamage();
        }
        return base * SpearTuning.lerp(SpearTuning.THROW_MULT_MIN, SpearTuning.THROW_MULT_MAX, power);
    }

    private void hitEntity(EntityLivingBase target) {
        hitIds.add(target.getEntityId());
        Entity owner = getOwner();
        boolean hurt = target.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), getThrowDamage());
        if (hurt) {
            double h = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (h > 1.0E-4D) {
                float kb = SpearTuning.lerp(SpearTuning.THROW_KNOCKBACK_MIN, SpearTuning.THROW_KNOCKBACK_MAX, power);
                target.addVelocity(this.motionX / h * kb, 0.1D, this.motionZ / h * kb);
            }
            world.playSound(null, target.posX, target.posY, target.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG,
                    SoundCategory.PLAYERS, 0.8F, 1.0F);
        }
        this.motionX *= SpearTuning.PIERCE_SLOWDOWN;
        this.motionY *= SpearTuning.PIERCE_SLOWDOWN;
        this.motionZ *= SpearTuning.PIERCE_SLOWDOWN;
    }

    // ---------- попадание в блок ----------

    private void stickInBlock(RayTraceResult hit, Vec3d dir) {
        Vec3d p = hit.hitVec;
        double back = TIP - 0.25D;
        setPosition(p.x - dir.x * back, p.y - dir.y * back, p.z - dir.z * back);
        this.motionX = 0.0D;
        this.motionY = 0.0D;
        this.motionZ = 0.0D;
        this.velocityChanged = true;
        setState(STUCK);
        this.stuckTicks = 0;
        hitIds.clear();

        world.playSound(null, p.x, p.y, p.z, SoundEvents.ENTITY_ARROW_HIT, SoundCategory.PLAYERS, 1.0F, 0.8F);
        if (!noWave) {
            shockwave(p, hit.getBlockPos());
            breakBlocks(p, dir);
        }
        noWave = true;
    }

    private void shockwave(Vec3d c, BlockPos blockPos) {
        float radius = SpearTuning.lerp(SpearTuning.WAVE_RADIUS_MIN, SpearTuning.WAVE_RADIUS_MAX, power);
        float damage = SpearTuning.lerp(SpearTuning.WAVE_DAMAGE_MIN, SpearTuning.WAVE_DAMAGE_MAX, power);
        int slow = (int) SpearTuning.lerp(SpearTuning.WAVE_SLOW_TICKS_MIN, SpearTuning.WAVE_SLOW_TICKS_MAX, power);

        Entity owner = getOwner();
        AxisAlignedBB area = new AxisAlignedBB(c.x - radius, c.y - 1.0D, c.z - radius, c.x + radius, c.y + 2.5D, c.z + radius);
        List<EntityLivingBase> victims = SpearTuning.WAVE_ENABLED
                ? world.getEntitiesWithinAABB(EntityLivingBase.class, area)
                : new ArrayList<EntityLivingBase>();
        for (EntityLivingBase e : victims) {
            if (e == owner || !e.isEntityAlive()) {
                continue;
            }
            double dx = e.posX - c.x;
            double dz = e.posZ - c.z;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > radius) {
                continue;
            }
            float falloff = 1.0F - (float) (dist / radius) * 0.5F;
            e.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), damage * falloff);
            e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, slow, SpearTuning.WAVE_SLOW_LEVEL));
            if (dist > 1.0E-3D) {
                e.addVelocity(dx / dist * 0.4D * falloff, 0.25D, dz / dist * 0.4D * falloff);
            }
        }

        world.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.5F, 1.4F);
        if (world instanceof WorldServer) {
            WorldServer ws = (WorldServer) world;
            int n = 18 + (int) (radius * 6.0F);
            for (int i = 0; i < n; i++) {
                double a = Math.PI * 2.0D * i / n;
                double cx = Math.cos(a);
                double cz = Math.sin(a);
                ws.spawnParticle(EnumParticleTypes.CLOUD, c.x + cx * 0.4D, c.y + 0.15D, c.z + cz * 0.4D, 0, cx, 0.02D, cz, 0.45D);
            }
            IBlockState state = world.getBlockState(blockPos);
            if (state.getBlock() != net.minecraft.init.Blocks.AIR) {
                ws.spawnParticle(EnumParticleTypes.BLOCK_CRACK, c.x, c.y + 0.1D, c.z, 40,
                        radius * 0.25D, 0.1D, radius * 0.25D, 0.15D, Block.getStateId(state));
            }
        }
    }

    /** Воронка в блоках вокруг точки попадания: как маленький взрыв. */
    private void breakBlocks(Vec3d hitVec, Vec3d dir) {
        if (!SpearTuning.BLOCK_BREAK_ENABLED) {
            return;
        }
        float r = SpearTuning.lerp(SpearTuning.BREAK_RADIUS_MIN, SpearTuning.BREAK_RADIUS_MAX, power);
        Vec3d c = hitVec.add(dir.scale(0.3D));
        BlockPos origin = new BlockPos(c);
        int ir = MathHelper.ceil(r);
        int broken = 0;
        for (int dx = -ir; dx <= ir; dx++) {
            for (int dy = -ir; dy <= ir; dy++) {
                for (int dz = -ir; dz <= ir; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d > r) {
                        continue;
                    }
                    // неровный край воронки
                    if (d > r * 0.6D && world.rand.nextFloat() < (float) ((d - r * 0.6D) / (r * 0.4D)) * 0.6F) {
                        continue;
                    }
                    BlockPos bp = origin.add(dx, dy, dz);
                    IBlockState st = world.getBlockState(bp);
                    if (st.getBlock().isAir(st, world, bp) || st.getMaterial().isLiquid()) {
                        continue;
                    }
                    float hardness = st.getBlockHardness(world, bp);
                    if (hardness < 0.0F || hardness > SpearTuning.BREAK_MAX_HARDNESS) {
                        continue;
                    }
                    if (world.getTileEntity(bp) != null) {
                        continue; // сундуки, печи, спавнеры не трогаем
                    }
                    world.destroyBlock(bp, true);
                    broken++;
                }
            }
        }
        if (broken > 0 && world instanceof WorldServer) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, c.x, c.y, c.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    // ---------- воткнуто ----------

    private void tickStuck() {
        stuckTicks++;
        if (stuckTicks > SpearTuning.STUCK_LIFETIME_TICKS) {
            dropAsItem();
            return;
        }
        // блок под остриём исчез -> копьё падает
        if (stuckTicks % 10 == 0) {
            float yr = this.rotationYaw * 0.017453292F;
            float pr = this.rotationPitch * 0.017453292F;
            double dx = MathHelper.sin(yr) * MathHelper.cos(pr);
            double dy = MathHelper.sin(pr);
            double dz = MathHelper.cos(yr) * MathHelper.cos(pr);
            BlockPos bp = new BlockPos(this.posX + dx * (TIP - 0.05D), this.posY + dy * (TIP - 0.05D), this.posZ + dz * (TIP - 0.05D));
            IBlockState st = world.getBlockState(bp);
            if (st.getCollisionBoundingBox(world, bp) == Block.NULL_AABB) {
                setState(FLYING);
                flightTicks = 0;
                this.motionX = 0.0D;
                this.motionY = -0.05D;
                this.motionZ = 0.0D;
                this.velocityChanged = true;
            }
        }
    }

    @Override
    public void onCollideWithPlayer(EntityPlayer player) {
        if (world.isRemote || getState() != STUCK || stuckTicks < 10) {
            return;
        }
        if (creativeThrow) {
            if (ownerId != null && ownerId.equals(player.getUniqueID())) {
                world.playSound(null, player.posX, player.posY, player.posZ, SoundEvents.ENTITY_ITEM_PICKUP,
                        SoundCategory.PLAYERS, 0.3F, 1.2F);
                setDead();
            }
            return;
        }
        if (player.inventory.addItemStackToInventory(getStack().copy())) {
            player.onItemPickup(this, 1);
            setDead();
        }
    }

    // ---------- возврат ----------

    private void tickReturning() {
        EntityPlayer owner = getOwner();
        if (owner == null || owner.isDead) {
            dropAsItem();
            return;
        }
        Vec3d target = new Vec3d(owner.posX, owner.posY + owner.height * 0.6D, owner.posZ);
        Vec3d to = target.subtract(this.posX, this.posY, this.posZ);
        double dist = to.lengthVector();
        if (dist < 1.4D) {
            giveToOwner(owner);
            return;
        }
        double spd = Math.min((double) SpearTuning.RETURN_SPEED, dist);
        Vec3d v = to.scale(spd / dist);
        this.motionX = v.x;
        this.motionY = v.y;
        this.motionZ = v.z;
        advance();
        this.velocityChanged = true;
    }

    private void giveToOwner(EntityPlayer owner) {
        if (!creativeThrow) {
            ItemStack s = getStack().copy();
            if (!owner.inventory.addItemStackToInventory(s)) {
                owner.dropItem(s, false);
            }
        }
        world.playSound(null, owner.posX, owner.posY, owner.posZ, SoundEvents.ENTITY_ITEM_PICKUP,
                SoundCategory.PLAYERS, 0.4F, 1.0F);
        setDead();
    }

    private void dropAsItem() {
        if (!creativeThrow && !getStack().isEmpty()) {
            entityDropItem(getStack().copy(), 0.0F);
        }
        setDead();
    }

    // ---------- вращение ----------

    private void updateRotationFromMotion() {
        float h = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        if (h < 1.0E-4F && Math.abs(this.motionY) < 1.0E-4D) {
            return;
        }
        this.rotationYaw = (float) (MathHelper.atan2(this.motionX, this.motionZ) * (180.0D / Math.PI));
        this.rotationPitch = (float) (MathHelper.atan2(this.motionY, (double) h) * (180.0D / Math.PI));
    }

    private void wrapRotation() {
        while (this.rotationPitch - this.prevRotationPitch < -180.0F) {
            this.prevRotationPitch -= 360.0F;
        }
        while (this.rotationPitch - this.prevRotationPitch >= 180.0F) {
            this.prevRotationPitch += 360.0F;
        }
        while (this.rotationYaw - this.prevRotationYaw < -180.0F) {
            this.prevRotationYaw -= 360.0F;
        }
        while (this.rotationYaw - this.prevRotationYaw >= 180.0F) {
            this.prevRotationYaw += 360.0F;
        }
    }

    // ---------- сохранение ----------

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {
        if (c.hasUniqueId("Owner")) {
            this.ownerId = c.getUniqueId("Owner");
        }
        setStack(new ItemStack(c.getCompoundTag("Stack")));
        setState(c.getByte("State"));
        this.power = c.getFloat("Power");
        this.creativeThrow = c.getBoolean("Creative");
        this.noWave = c.getBoolean("NoWave");
        this.stuckTicks = c.getInteger("StuckTicks");
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {
        if (ownerId != null) {
            c.setUniqueId("Owner", ownerId);
        }
        c.setTag("Stack", getStack().writeToNBT(new NBTTagCompound()));
        c.setByte("State", (byte) getState());
        c.setFloat("Power", power);
        c.setBoolean("Creative", creativeThrow);
        c.setBoolean("NoWave", noWave);
        c.setInteger("StuckTicks", stuckTicks);
    }
}
