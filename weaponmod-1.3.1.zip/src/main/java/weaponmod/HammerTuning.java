package weaponmod;

/** Числа баланса молота Тора. */
public final class HammerTuning {

    private HammerTuning() {}

    public static final int MAX_USES = 1561;

    // ближний бой (тяжёлый и медленный)
    public static final float MELEE_DAMAGE = 24.0F;
    public static final double MELEE_ATTACK_SPEED = -3.0D;

    // молния от взмаха
    /** Радиус «зрения» молота: цель (моб или блок) по линии взгляда в этом радиусе. */
    public static final double STRIKE_RADIUS = 15.0D;
    public static final int STRIKE_COOLDOWN = 25;
    /** Урон одной молнии каждому в зоне (ваниль: 5). */
    public static final float BOLT_DAMAGE = 15.0F;
    /** Радиус поражения молнии вокруг точки удара. */
    public static final double LIGHTNING_AOE = 7.0D;

    /** Ближе этого расстояния до игрока (в т. ч. под ногами) молния не бьёт. */
    public static final double MIN_LIGHTNING_DISTANCE = 2.0D;

    // разрушение блоков, если молот «касается» блока
    public static final boolean BLOCK_BREAK_ENABLED = true;
    public static final double CONTACT_RANGE = 3.5D;
    public static final float CRATER_RADIUS = 3.5F;
    public static final float CRATER_MAX_RADIUS = 5.5F;
    public static final float CRATER_MAX_HARDNESS = 3.0F;

    // заряд (удержание ПКМ)
    public static final int CHARGE_MIN_TICKS = 10;
    public static final int CHARGE_FULL_TICKS = 40;
    public static final int CHARGED_COOLDOWN = 40;
    /** Молний при полном заряде (минимум 1). */
    public static final int CHARGED_BOLTS_MAX = 4;
    public static final double CHARGED_BOLT_SPREAD = 4.0D;
    /** Множитель урона молнии при полном заряде = 1 + это. */
    public static final float CHARGED_DAMAGE_BONUS = 2.0F;

    // падение: урон растёт с высотой падения (она растёт со скоростью)
    public static final float FALL_DAMAGE_PER_BLOCK = 1.2F;
    public static final float FALL_BONUS_MAX_DISTANCE = 40.0F;

    // удар под ноги: подбрасывает игрока и гасит падение (как вода)
    /** Считается «под ноги», если взгляд направлен вниз сильнее этого (y-компонента взгляда). */
    public static final double UNDERFOOT_LOOK_Y = -0.7D;
    public static final double LAUNCH_BASE = 1.1D;
    public static final double LAUNCH_PER_FALL = 0.04D;
    public static final double LAUNCH_MAX = 3.0D;
    /** Сколько тиков действует защита от урона падением после подброса. */
    public static final int NOFALL_WINDOW = 600;
}
